"""Publish a label-free replay of method synthesis and each exploration ranking."""
import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from superagent.ab_method_search import rank
from superagent.open_methods import MethodSpace
from superagent.scheduler_bridge import fingerprint


def read(path):
    return json.loads(path.read_text())


def collect(folder):
    native=folder/'agent'
    manifest=read(native/'run_manifest.json')
    history=read(native/'history.json')
    actions=read(native/'actions.json')
    entries=read(native/'prediction_evidence.json')
    steps=[]
    for i,action in enumerate(actions,1):
        record=dict(action=action['action'])
        if manifest['local_method_search']=='open':
            receipt=read(native/f'method_space_{i}.json')
            record.update(registry_hash=receipt['sha256'],proposed=len(receipt['generated']),new_count=len(receipt['newly_seen']))
        if action['action']=='explore':
            choice=read(native/f'method_choice_{i}.json')
            record.update(eligible=[s['candidate'] for s in choice['candidates']],
                          chosen=choice['chosen'],ranking_hash=fingerprint(choice))
        steps.append(record)
    rows=[{k:r[k] for k in ('candidate','trial','split_id','status','search_score','train_score')} for r in history]
    return dict(task=manifest['task_contract'],base=manifest['capabilities'],profile=read(native/'training_profile.json'),
                mode=manifest['local_method_search'],history=rows,
                primary_predictions=[{'trial':v['trial'],'predictions':v['predictions']} for v in entries if v['split_id']=='primary'],
                steps=steps)


def replay(obj):
    p=obj['profile']
    task=obj['task']
    evidence={v['trial']:v for v in obj['primary_predictions']}
    with TemporaryDirectory() as folder:
        space=MethodSpace(task,p,Path(folder)) if obj['mode']=='open' else None
        for i,step in enumerate(obj['steps']):
            history=obj['history'][:i]
            caps=obj['base']
            if space:
                caps,receipt=space.refresh(history,caps)
                if receipt['sha256']!=step['registry_hash'] or len(receipt['newly_seen'])!=step['new_count']:
                    raise ValueError('Could not reproduce run-time generation at action '+str(i+1))
            if step['action']!='explore':
                continue
            primary=sorted((r for r in history if r['split_id']=='primary'),key=lambda r:(-r['search_score'],r['candidate']))
            state=dict(training_profile=p,prediction_evidence=[evidence[r['trial']] for r in primary])
            result=rank(state,caps,step['eligible'],primary)
            backwards=rank(state,dict(reversed(caps.items())),list(reversed(step['eligible'])),primary)
            if result!=backwards or fingerprint(result)!=step['ranking_hash'] or result['chosen']!=step['chosen']:
                raise ValueError('Could not reproduce exploration at action '+str(i+1))
    return sum(s['action']=='explore' for s in obj['steps'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file',type=Path)
    parser.add_argument('--runs',type=Path,nargs='+')
    a=parser.parse_args()
    if a.runs:
        data={folder.name:collect(folder) for run in a.runs for folder in sorted(run.iterdir()) if (folder/'receipt.json').is_file()}
        with a.file.open('x') as f:
            json.dump(data,f,ensure_ascii=False,separators=(',',':'),allow_nan=False)
    else:
        data=read(a.file)
    count=sum(replay(obj) for obj in data.values())
    print('Reproduced',count,'rankings and the registered candidate spaces for',len(data),'paths')
