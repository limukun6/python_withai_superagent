"""Represent the changed passages in two items while retaining the complete independent views."""
from difflib import SequenceMatcher
import re

import numpy as np

from .minilm_features import MiniLMTextClassifier


def focus_pair(left, right, control=False):
    """Canonical alignment gives the same passages when the preference order is reversed."""
    if left == right:
        return (left, right), False
    if left > right:
        result, cropped = focus_pair(right, left, control)
        return (result[1], result[0]), cropped
    sides = (left, right)
    spans = [list(re.finditer(r'\w+|[^\w\s]', text)) for text in sides]
    tokens = [[m.group() for m in runs] for runs in spans]
    # Bound the quadratic alignment cost on an unseen long document.
    if not all(tokens) or max(map(len, tokens)) > 256:
        return sides, False
    keep = [np.zeros(len(t), dtype=bool) for t in tokens]
    matcher = SequenceMatcher(a=tokens[0], b=tokens[1], autojunk=False)
    for op, i, j, p, q in matcher.get_opcodes():
        if op != 'equal':
            for mask, lo, hi in ((keep[0], i, j), (keep[1], p, q)):
                mask[max(0, lo - 1):min(len(mask), hi + 1)] = True
    if not all(m.any() for m in keep) or all(m.all() for m in keep):
        return sides, False
    views = []
    for text, runs, keep_side in zip(sides, spans, keep, strict=True):
        if keep_side.all():
            views.append(text)
            continue
        if control:
            # A content-blind centred crop preserves the per-side number of selected tokens.
            width = int(keep_side.sum())
            begin = (len(runs) - width) // 2
            views.append(text[runs[begin].start():runs[begin + width - 1].end()])
            continue
        indices = np.flatnonzero(keep_side)
        pieces = np.split(indices, np.flatnonzero(np.diff(indices) != 1) + 1)
        views.append(' … '.join(text[runs[part[0]].start():runs[part[-1]].end()] for part in pieces))
    return tuple(views), True


class EditViewClassifier(MiniLMTextClassifier):
    def __init__(self, runtime, control=False):
        super().__init__('pair_text', runtime, False)
        self.control = control

    def dense_features(self, rows):
        full = super().dense_features(rows)
        residual = np.zeros_like(full)
        indices, views = [], []
        for i, (left, right) in enumerate(rows):
            passages, changed = focus_pair(left, right, self.control)
            if changed:
                indices.append(i)
                views.append(passages)
        if views:
            residual[indices] = super().dense_features(views) - full[indices]
        return np.column_stack((full, residual))
