"""Compare independent and joint attention using one pinned encoder and the same lexical classifier."""
import argparse
import hashlib
import json
import os
from pathlib import Path

import joblib
import numpy as np
from scipy.sparse import csr_matrix,hstack,vstack
from sklearn.base import clone
from threadpoolctl import threadpool_limits

from superagent.data import load_training_task
from superagent.minilm_features import FILES,MiniLMTextClassifier
from superagent.pair_attention import PairAttentionEncoder
from superagent.pretrained_choice import digest
from superagent.splits import take
from tools.error_specialist_study import require
from tools.pretrained_study import read,write,train_only
from tools.residual_memory_study import CachedVectors
from tools.soft_vote_diagnostic import freeze_file


MODES=('blocked','joint')


def freeze(args):
    repo=Path(__file__).resolve().parents[1]
    prior=read(args.reference/'protocol.json')
    strong=read(args.strong/'protocol.json')
    require(prior['indices']==strong['indices'] and prior['archive_sha256']==strong['archive_sha256']==digest(args.archive),
            'Training folds or archive do not match the stronger comparator')
    sources=[]
    for i in range(5):
        fold=f'fold_{i}'
        source=args.reference/fold/args.arm
        sources.append(dict(model=digest(source/'selected_model.joblib'),selection=digest(source/'final_selection.json'),
                      base=digest(args.reference/fold/'outer_predictions.json'),strong=digest(args.strong/fold/'outer_predictions.json')))
    return dict(code={p:digest(repo/p) for p in ('tools/pair_attention_study.py','superagent/pair_attention.py',
                        'superagent/minilm_features.py','tools/residual_memory_study.py')},
                root_protocol_sha256=digest(args.reference/'protocol.json'),strong_protocol_sha256=digest(args.strong/'protocol.json'),
                archive_sha256=prior['archive_sha256'],seed=prior['seed'],folds=sources,arms=list(MODES),
                original_arm=args.arm,stronger_arm=args.strong_arm,
                weights={f:spec[1] for f,spec in FILES.items()},
                rule='Same encoder, tied segment IDs, reset positions, equal lexical features, dimensions, classifier '
                     'and training rows. Compare block-diagonal attention to attention across the pair. Compare with '
                     'the published small model and a stronger dual-encoder arm on identical development rows. '
                     'A frozen input-only transform may be cached across folds; no class labels enter encoding. '
                     'Augment training only by reversing the two items and the preference.',
                promotion='At least +0.2 pp and three strict fold wins versus blocked, default, and stronger option. '
                          'Qualifying performance needs another stratified grouped split.')


def training(args):
    opened=[]
    with train_only(args.archive,opened):
        data=load_training_task(args.archive)
    require(data.kind=='pair_text','This comparison requires two declared preference items')
    splits=read(args.reference/'protocol.json')['indices']
    ids=sorted(i for s in splits for i in s['outer'])
    require(len(ids)==len(set(ids)) and all(set(s['train'])|set(s['outer'])==set(ids)
            and not set(s['train'])&set(s['outer']) for s in splits),'Bad development partitions')
    return data,splits,ids,opened


def feature_key(args,data,ids):
    content=json.dumps(take(data.X_train,ids),ensure_ascii=False,separators=(',',':')).encode()
    return dict(raw_ids_sha256=hashlib.sha256(np.asarray(ids,dtype='<i8').tobytes()).hexdigest(),
                input_pairs_sha256=hashlib.sha256(content).hexdigest(),
                encoder_sha256=digest(Path(__file__).resolve().parents[1]/'superagent/pair_attention.py'),
                weights={f:meta[1] for f,meta in FILES.items()})


def encode(args):
    data,_,ids,opened=training(args)
    key=feature_key(args,data,ids)
    if (args.cache/'receipt.json').is_file():
        rec=read(args.cache/'receipt.json')
        require(rec['key']==key and rec['file_sha256']==digest(args.cache/'features.npz'),'Wrong or damaged cached representation')
        return
    args.cache.mkdir(parents=True,exist_ok=True)
    encoder=PairAttentionEncoder(args.weights)
    inputs=take(data.X_train,ids)
    canonical=sorted(set(tuple(sorted(pair)) for pair in inputs))
    loc={p:i for i,p in enumerate(canonical)}
    index=np.asarray([loc[tuple(sorted(p))] for p in inputs])
    signs=np.asarray([1. if a<b else -1. if a>b else 0. for a,b in inputs],dtype=np.float32)
    vectors={}
    for mode in MODES:
        features=encoder.difference(canonical,mode)
        vectors[mode]=features[index]*signs[:,None]
        print(mode,'encoded',len(canonical),'pairs',flush=True)
    path=args.cache/'features.npz'
    np.savez_compressed(path,ids=np.asarray(ids),**vectors)
    write(args.cache/'receipt.json',dict(key=key,file_sha256=digest(path),training_members=opened,
              unique_pairs=len(canonical),rows=len(ids),usage=encoder.usage,device='cpu',new_llm_calls=0,api_rmb=0))


def fit(args):
    data,splits,ids,_=training(args)
    rec=read(args.cache/'receipt.json')
    require(rec['key']==feature_key(args,data,ids) and rec['file_sha256']==digest(args.cache/'features.npz'),
            'Wrong cached observations')
    loc={r:i for i,r in enumerate(ids)}
    receipts=[]
    with np.load(args.cache/'features.npz') as store,threadpool_limits(limits=1):
        np.testing.assert_array_equal(store['ids'],ids)
        vectors={m:store[m] for m in MODES}
        for i,s in enumerate(splits):
            folder=f'fold_{i}'
            source=args.reference/folder/args.arm
            dest=args.out/folder
            dest.mkdir(exist_ok=True)
            model=joblib.load(source/'selected_model.joblib')['model']
            require(type(model) is MiniLMTextClassifier,'Require the same light lexical-plus-L6 incumbent')
            blocks=[]
            discrepancies=[]
            for part,cache in [('train',source),('outer',source.parent/(args.arm+'_prediction_features'))]:
                rows=s[part]
                indices=np.asarray([loc[j] for j in rows])
                model.encoder=CachedVectors(cache)
                base=model.features(take(data.X_train,rows))
                d=vectors['blocked'].shape[1]
                error=float(np.max(np.abs(base[:,-d:].toarray()-vectors['blocked'][indices])))
                require(error < 1e-4,'Blocked attention differs from the independent encoder beyond tolerance')
                discrepancies.append(error)
                blocks.append({m:hstack((base[:,:-d],csr_matrix(vectors[m][indices])),format='csr') for m in MODES})
            y=data.y_train[s['train']]
            augmented=np.r_[y,1-y]
            predictions={}
            for mode in MODES:
                x=blocks[0][mode]
                fitted=clone(model.classifier).fit(vstack((x,-x)),augmented)
                predictions[mode]=fitted.predict(blocks[1][mode]).tolist()
                path=dest/(mode+'.joblib')
                joblib.dump(fitted,path,compress=3)
                np.testing.assert_array_equal(joblib.load(path).predict(blocks[1][mode][:12]),predictions[mode][:12])
            base=read(args.reference/folder/'outer_predictions.json')
            strong=read(args.strong/folder/'outer_predictions.json')
            require(base['rows']==strong['rows']==s['outer'],'Outer sample order differs')
            predictions.update(default=base[args.arm],strong=strong[args.strong_arm])
            write(dest/'predictions.json',dict(rows=s['outer'],arms=predictions))
            receipts.append(dict(predictions=digest(dest/'predictions.json'),numerical_blocked_errors=discrepancies,
                           blocked_prediction_differences=int(np.sum(np.asarray(predictions['blocked'])!=predictions['default'])),
                           heads={m:digest(dest/(m+'.joblib')) for m in MODES}))
            print('sealed',folder,flush=True)
    write(args.out/'sealed.json',dict(folds=receipts,feature_receipt_sha256=digest(args.cache/'receipt.json'),
                                     protocol_sha256=digest(args.out/'protocol.json')))


def score(args):
    data,splits,_,opened=training(args)
    receipt=read(args.out/'sealed.json')
    require(receipt['protocol_sha256']==digest(args.out/'protocol.json') and
            digest(args.cache/'receipt.json')==receipt['feature_receipt_sha256'],'Frozen evidence changed')
    folds=[]
    for i,(split,rec) in enumerate(zip(splits,receipt['folds'],strict=True)):
        path=args.out/f'fold_{i}/predictions.json'
        require(rec['predictions']==digest(path),'Changed predictions')
        batch=read(path)
        require(batch['rows']==split['outer'],'Different outer IDs')
        y=data.y_train[split['outer']]
        masks={a:np.asarray(p)==y for a,p in batch['arms'].items()}
        folds.append(dict(rows=len(y),correct={a:int(m.sum()) for a,m in masks.items()},
                         paired={a:dict(corrected=int((masks['joint']&~m).sum()),lost=int((~masks['joint']&m).sum()))
                                 for a,m in masks.items() if a!='joint'}))
    n=sum(f['rows'] for f in folds)
    correct={a:sum(f['correct'][a] for f in folds) for a in folds[0]['correct']}
    wins={a:sum(f['correct']['joint']>f['correct'][a] for f in folds) for a in ('default','strong','blocked')}
    write(args.out/'results.json',dict(rows=n,correct=correct,folds=folds,wins=wins,training_members=opened,
           qualified=all(correct['joint']-correct[a]>=.002*n and wins[a]>=3 for a in wins),
           classifier_fits=2*len(folds),feature_receipt=read(args.cache/'receipt.json'),
           llm_calls=0,incremental_rmb=0,sealed_sha256=digest(args.out/'sealed.json')))
    print(correct,wins)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase',choices=('freeze','encode','fit','score'))
    for n in ('archive','reference','strong','out','cache','weights'):
        parser.add_argument('--'+n,type=Path,required=True)
    parser.add_argument('--arm',default='auto')
    parser.add_argument('--strong-arm',default='encoder-mixture-wide')
    args=parser.parse_args()
    os.environ['SUPERAGENT_OFFLINE']='1'
    if args.phase=='freeze':
        args.out.mkdir(parents=True,exist_ok=False)
    else:
        require((args.out/'protocol.json').is_file(),'Freeze this comparison first')
    freeze_file(args.out/'protocol.json',freeze(args))
    if args.phase=='encode':
        encode(args)
    elif args.phase=='fit':
        require(not (args.out/'sealed.json').exists(),'Already sealed')
        fit(args)
    elif args.phase=='score':
        score(args)
