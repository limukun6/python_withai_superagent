"""Sealed comparison of the same autonomous search with and without run-time synthesis."""
import argparse
import csv
from dataclasses import dataclass
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

import numpy as np
from sklearn.datasets import load_digits,load_wine
from sklearn.metrics import accuracy_score,f1_score

from superagent.ab_run import sha,sources
from superagent.ab_catalog import untried_candidates
from superagent.ab_method_search import rank
from superagent.ab_scheduler import next_action,selection_evidence
from superagent.contracts import TaskSpec
from superagent.data import load_development_task
from superagent.open_methods import MethodSpace,materialize
from superagent.scheduler_bridge import fingerprint
from superagent.splits import normalized_text,sample_groups
from superagent.task_profile import training_facts
from superagent.ab_run import freeze_partitions,registered_capabilities
from tempfile import TemporaryDirectory


ROOT=Path(__file__).resolve().parents[1]
PLAN=ROOT/'docs/batches/B_open_methods_protocol_20261124_zh.md'
SMS_SHA='1587ea43e58e82b14ff1f5425c88e17f8496bfcdb67a583dbff9eefaf9963ce3'
SEED=60281
TASKS={'q0':('tabular','accuracy'),'q1':('tabular','macro_f1'),'q2':('text','macro_f1'),'q3':('image','accuracy')}
PATHS=[('q0','open',5),*[(slot,mode,6) for slot in ('q1','q2','q3') for mode in ('evidence','open')]]


def require(ok,reason):
    if not ok:
        raise ValueError(reason)


def read(file):
    return json.loads(file.read_text())


def save(file,record):
    if file.exists():
        require(read(file)==record,'Frozen report changed: '+file.name)
    else:
        with file.open('x') as f:
            json.dump(record,f,indent=2,ensure_ascii=False,allow_nan=False)


def bin_id(value,salt,mod):
    return int.from_bytes(hashlib.sha256(salt.encode()+value).digest(),'big')%mod


def packet(dest,slot,x,y=None):
    modality,metric=TASKS[slot]
    split='train' if y is not None else 'test'
    descriptor=dict(format='npz',path='rows.npz')
    manifest=dict(schema_version=1,objective='classification',metric=metric,modality=modality,splits={split:descriptor})
    if modality=='text':
        descriptor.update(format='csv',path='rows.csv')
        manifest.update(columns=[dict(name='x',type='text')],target='y')
        stream=io.StringIO(newline='')
        writer=csv.writer(stream)
        writer.writerow(['x','y'] if y is not None else ['x'])
        writer.writerows(zip(x,y,strict=True) if y is not None else ((s,) for s in x))
        data=stream.getvalue().encode()
    else:
        stream=io.BytesIO()
        np.savez(stream,X=x,**({'y':y} if y is not None else {}))
        data=stream.getvalue()
    with zipfile.ZipFile(dest,'x') as archive:
        for name,blob in (('manifest.json',json.dumps(manifest).encode()),(descriptor['path'],data)):
            info=zipfile.ZipInfo(name,(2020,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,blob)


def prepare(out,sms):
    require(sha(sms)==SMS_SHA,'Different source SMS archive')
    out.mkdir(parents=True,exist_ok=False)
    rng=np.random.default_rng(1109)
    x=rng.normal(size=(160,5))
    with zipfile.ZipFile(sms) as archive:
        texts=[line.split('\t',1) for line in archive.read('SMSSpamCollection').decode('utf-8-sig').splitlines() if '\t' in line]
    texts=[(y,s) for y,s in texts if bin_id(normalized_text(s).encode(),'b-open-sms-sample-v1/',8)<3]
    wy=load_wine()
    dy=load_digits()
    arrays={'q0':(x,(x[:,0]*x[:,1]>0).astype(int)),'q1':(wy.data,wy.target),
            'q2':(np.array([s for _,s in texts]),np.array([y for y,_ in texts])),'q3':(dy.images,dy.target)}
    notes={}
    for slot,(x,y) in arrays.items():
        keys=[normalized_text(v).encode() if slot=='q2' else np.ascontiguousarray(v).tobytes() for v in x]
        hold=np.array([bin_id(v,'b-open-space-20261124/v1/',5)==0 for v in keys])
        group=[hashlib.sha256(v).hexdigest() for v in keys]
        groups=np.array(group)
        require(set(groups[hold]).isdisjoint(groups[~hold]) and set(y[hold])==set(y[~hold]),'Outer grouping/class coverage')
        folder=out/'inputs'/slot
        folder.mkdir(parents=True)
        packet(folder/'train.zip',slot,x[~hold],y[~hold])
        packet(folder/'features.zip',slot,x[hold])
        np.save(folder/'scoring.npy',y[hold],allow_pickle=False)
        tags=load_development_task(folder/'train.zip')
        require(tags.y_val is None and np.array_equal(tags.y_train.astype(str),y[~hold].astype(str)),'Wrong anonymous contract')
        notes[slot]=dict(train_rows=int(sum(~hold)),outer_rows=int(sum(hold)),classes=int(len(set(y))),outer_groups=len(set(groups[hold])),
                         class_labels=sorted(set(y.tolist())),metric=TASKS[slot][1],shared_feature_groups=0,
                         files={f.name:sha(f) for f in folder.iterdir()})
    save(out/'protocol.json',dict(source=sources(),plan=sha(PLAN),runner=sha(Path(__file__)),guard=sha(ROOT/'scripts/ab_acceptance_guard/sitecustomize.py'),
                                  seed=SEED,fit_cap=sum(a[2] for a in PATHS),api_cap=0,tasks=notes,sms_sha=SMS_SHA))


def cli(args,trace,log,timeout):
    env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(ROOT/'scripts/ab_acceptance_guard'),str(ROOT)]),AB_B1_OFFLINE='1',
             AB_B1_FIT_LOG=str(trace),AB_B1_PER_WORKER_FIT_LIMIT='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',
             VECLIB_MAXIMUM_THREADS='2',TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    # Supply the same locally available original methods in both arms.
    for var,key in (('SUPERAGENT_MINILM_WEIGHTS','all-MiniLM-L6-v2'),('SUPERAGENT_DEEP_MINILM_WEIGHTS','all-MiniLM-L12-v2'),
                    ('SUPERAGENT_E5_SMALL_WEIGHTS','e5-small-v2')):
        env[var]=str(ROOT.parent/'pretrained_weights'/key)
    with log.open('x') as stream:
        subprocess.run([sys.executable,'-m','superagent',*map(str,args)],env=env,cwd=ROOT,stdin=subprocess.DEVNULL,
                       stdout=stream,stderr=subprocess.STDOUT,timeout=timeout,check=True)


def audit(out,slot,mode,limit):
    folder=out/f'{slot}_{mode}'
    native=folder/'agent'
    p=read(out/'protocol.json')
    manifest=read(native/'run_manifest.json')
    outcome=read(native/'run_outcome.json')
    require(outcome['status']=='completed' and outcome['source_unchanged'] and outcome['requested_planner_completed']
            and outcome['new_api_requests']==0 and outcome['full_refit_completed'] and not outcome['formal_test_accessed'],
            'Uncompleted native run: '+str(outcome.get('error',outcome['status'])))
    require(manifest['source_files']==p['source'] and manifest['task_archive_sha256']==p['tasks'][slot]['files']['train.zip']
            and manifest['local_method_search']==mode and manifest['fit_limit']==limit and manifest['llm_request_limit']==0,
            'Changed native contract')
    task=load_development_task(out/'inputs'/slot/'train.zip')
    spec=TaskSpec.from_task(task)
    profile=training_facts(task)
    actions=read(native/'actions.json')
    history=read(native/'history.json')
    meter=[json.loads(v) for v in (folder/'physical.jsonl').read_text().splitlines()]
    ledger=read(native/'classifier_fits.json')
    require(len(meter)==ledger['attempted_classifier_fits']==ledger['completed_classifier_fits']<=limit
            and not ledger['unknown_failed_attempts'] and all(m=={'candidate':w['candidate'],'classifier':w['calls'][0]['classifier']}
                for m,w in zip(meter,ledger['workers'],strict=True)),'Different worker fit ledger')
    final=read(native/'final_selection.json')
    base=manifest['capabilities']
    trials=[]
    with TemporaryDirectory() as scratch:
        temp=Path(scratch)
        trusted,allowed=freeze_partitions(task,temp,SEED,spec.metric)
        for name in allowed:
            require(sha(native/(name+'.joblib'))==allowed[name]['evaluation_payload_sha256'],'Different native fold')
        space=MethodSpace(spec.record(),profile,temp) if mode=='open' else None
        for i,action in enumerate(actions,1):
            state=read(native/f'state_{i}.json')
            require(state['task']==spec.record() and state['history']==history[:i-1] and state['training_profile']==profile and
                    state['budget']['remaining_fit_allowance']==limit-(i-1),'State, prefix or fit ledger differs')
            caps=base
            if space:
                caps,generation=space.refresh(history[:i-1],base)
                require(generation==read(native/f'method_space_{i}.json') and sha(native/generation['file'])==generation['sha256'],
                        'Could not regenerate the runtime inventory')
            require(state['available_candidates']==untried_candidates(caps,state['history']),'Visible menu differs')
            replay=next_action(state,trusted_partitions=trusted,capabilities=caps,on_local_method=lambda ids,rows:rank(state,caps,ids,rows))
            require(replay==action,'Could not reproduce native action')
            if i>len(history):
                continue
            row=history[i-1]
            entry=caps[row['candidate']]
            generated=entry['origin']=='runtime_composed'
            if generated:
                wire=read(native/generation['file'])
                require(row['candidate'] not in base and materialize(wire['entries'][row['candidate']]).family==row['candidate']
                        and row['resolved_configuration']['origin']=='registry' and
                        row['resolved_configuration']['registry_sha256']==generation['sha256'] and
                        row['estimator']['class']==entry['estimator_class'],'Generated candidate failed identity checks')
            trials.append(dict(step=i,action=action['action'],candidate=row['candidate'],actual_class=row['estimator']['class'],
                   split=row['split_id'],metric=row['primary_metric'],score=row['search_score'],generated=generated,
                   specification=entry['params'] if generated else None,prior_observations=action['evidence_trials']))
    require(selection_evidence(state,trusted_partitions=trusted)['incumbent']==final['family']==meter[-1]['candidate']
            and final['training_rows']==len(task.y_train) and sha(native/final['model_file'])==final['model_sha256'],'Final model selection')
    return dict(base_configs=len(base),model=final['model_sha256'],winner=final['family'],winner_generated=final['family'] not in base,
                initial_generated=0 if space is None else len(read(native/'method_space_1.json')['generated']),
                actual_fits=len(meter),physical=meter,actions=actions,trials=trials,actions_replayed=len(actions),api_calls=0)


def export(out,slot,mode,n,expected):
    folder=out/f'{slot}_{mode}'
    dest=folder/f'export_{n}'/'rows.csv'
    if not dest.exists():
        cli(['predict',out/'inputs'/slot/'features.zip','--run-dir',folder/'agent','--output',dest],
            folder/'physical.jsonl',folder/f'export_{n}.log',180)
    manifest=read(dest.parent/'prediction_manifest.json')
    require(manifest['prediction_count']==expected and not manifest['test_labels_read'],'Prediction count or data boundary')
    return sha(dest)


def run(out):
    p=read(out/'protocol.json')
    require(p['source']==sources() and p['plan']==sha(PLAN) and p['runner']==sha(Path(__file__)) and
            p['guard']==sha(ROOT/'scripts/ab_acceptance_guard/sitecustomize.py'),'Frozen study changed')
    sealed={}
    for slot,mode,limit in PATHS:
        key=f'{slot}_{mode}'
        folder=out/key
        train=out/'inputs'/slot/'train.zip'
        require(sha(train)==p['tasks'][slot]['files']['train.zip'],'Training input changed')
        if not (folder/'agent/run_outcome.json').is_file():
            folder.mkdir(exist_ok=False)
            cli(['run',train,'--scheduler','ab-v1','--planner','local','--portfolio','ab-v1','--task-profile','train',
                 '--local-method-search',mode,'--fit-limit',limit,'--seed',SEED,'--time-limit',600,'--trial-timeout',180,
                 '--run-dir',folder/'agent'],folder/'physical.jsonl',folder/'train.log',650)
        record=audit(out,slot,mode,limit)
        save(folder/'receipt.json',record)
        sealed[key]=sha(folder/'receipt.json')
        print(key,'sealed',record['winner'],record['actual_fits'],'fits',flush=True)
        if slot=='q0':
            expected=p['tasks'][slot]['outer_rows']
            require(export(out,slot,mode,0,expected)==export(out,slot,mode,1,expected),'Smoke exports differ')
    save(out/'models_frozen.json',sealed)
    predictions={}
    for slot,mode,_ in PATHS:
        key=f'{slot}_{mode}'
        meta=p['tasks'][slot]
        require(sha(out/key/'receipt.json')==sealed[key] and sha(out/'inputs'/slot/'features.zip')==meta['files']['features.zip'],
                'Different models or label-free features')
        exports=[export(out,slot,mode,i,meta['outer_rows']) for i in range(2)]
        require(exports[0]==exports[1],'Independent predictions differ')
        predictions[key]=exports
    save(out/'exports.json',predictions)
    scores={}
    for slot,mode,_ in PATHS:
        key=f'{slot}_{mode}'
        label_file=out/'inputs'/slot/'scoring.npy'
        require(sha(label_file)==p['tasks'][slot]['files']['scoring.npy'],'Score labels changed')
        labels=np.load(label_file,allow_pickle=False)
        with (out/key/'export_0/rows.csv').open() as f:
            rows=list(csv.DictReader(f))
        values=np.asarray([v['prediction'] for v in rows],dtype=labels.dtype)
        require([r['row_id'] for r in rows]==list(map(str,range(len(labels)))),'Export row order')
        scores[key]=dict(rows=len(labels),correct=int(sum(labels==values)),accuracy=accuracy_score(labels,values),
                         macro_f1=f1_score(labels,values,average='macro'),primary_metric=TASKS[slot][1])
    save(out/'results.json',scores)
    save(out/'completion.json',{k:sha(out/(k+'.json')) for k in ('protocol','exports','models_frozen','results')})
    print(json.dumps(scores),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase',choices=('prepare','run'))
    parser.add_argument('--out',type=lambda v:Path(v).resolve(),required=True)
    parser.add_argument('--sms',type=Path)
    args=parser.parse_args()
    if args.phase=='prepare':
        prepare(args.out,args.sms)
    else:
        run(args.out)
