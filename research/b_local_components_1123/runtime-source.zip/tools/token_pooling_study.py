"""Fit a token-level preference head on out-of-fit offsets from the ordinary lexical-plus-L6 model."""
import argparse
import time
from pathlib import Path

import joblib
import numpy as np
import torch
from sklearn.model_selection import StratifiedGroupKFold
from threadpoolctl import threadpool_limits

from superagent.minilm_features import FILES, MiniLMTextClassifier
from superagent.pretrained_choice import digest
from superagent.splits import sample_groups, take
from tools.error_specialist_study import require
from tools.pair_attention_study import training
from tools.pretrained_study import read, write
from tools.residual_memory_study import CachedVectors
from tools.soft_vote_diagnostic import freeze_file
from tools.token_value_head import BATCH, EPOCHS, MODES, SEED, WIDTH, Bank, extract, fit_head, predict_delta, text_key


def source(args, i):
    reference = read(args.reference/'protocol.json')
    return Path(reference['locations'][i][args.arm])


def frozen(args):
    root = Path(__file__).resolve().parents[1]
    ref, strong = [read(p/'protocol.json') for p in (args.reference, args.strong)]
    require(ref['indices'] == strong['indices'] and ref['archive_sha256'] == strong['archive_sha256'] == digest(args.archive),
            'The source models have different train/outer partitions')
    sources = []
    for i in range(5):
        folder = source(args, i)
        cache = folder.parent/(args.arm+'_prediction_features')
        sources.append(dict(model=digest(folder/'selected_model.joblib'),
                            fitting_vectors=digest(folder/'minilm_category_vectors.sqlite'),
                            outer_vectors=digest(cache/'minilm_category_vectors.sqlite'),
                            small=digest(args.reference/f'fold_{i}/outer_predictions.json'),
                            strong=digest(args.strong/f'fold_{i}/outer_predictions.json')))
    return dict(code={f:digest(root/f) for f in ('tools/token_pooling_study.py', 'tools/token_value_head.py',
                'tools/pair_attention_study.py', 'tools/residual_memory_study.py', 'superagent/pair_attention.py',
                'superagent/minilm_features.py')}, reference=digest(args.reference/'protocol.json'),
                stronger=digest(args.strong/'protocol.json'), sources=sources, seed=ref['seed'], archive=ref['archive_sha256'],
                width=WIDTH, seed_head=SEED, epochs=EPOCHS, batch=BATCH, modes=list(MODES), baseline=args.arm,
                stronger_arm=args.strong_arm, weights={n:v[1] for n,v in FILES.items()},
                rule='Hold all data-dependent text vocabulary and base classifier fitting inside each of two '
                     'disjoint shared-item folds. The token head sees only out-of-fit base logits on its training rows. '
                     'At prediction, retain the frozen previously selected whole-item logit and add a learned '
                     'antisymmetric adjustment. Mean pooling uses constant weights. Permuted pooling disconnects '
                     'attention keys from values within each item with the same parameter and data budget as learned pooling.',
                promotion='The learned head must gain at least 0.2 percentage points pooled and strictly win three '
                          'of five folds versus mean, permuted, the archived small and the archived dual-encoder model. '
                          'Repeat on another partition before using course validation.')


def text_inputs(args):
    data, splits, ids, opened = training(args)
    texts = sorted({t for i in ids for t in data.X_train[i]}, key=text_key)
    return data, splits, texts, opened


def header(texts):
    import hashlib
    signatures = ''.join(text_key(t) for t in texts).encode()
    return dict(texts_sha256=hashlib.sha256(signatures).hexdigest(),
                implementation=digest(Path(__file__).with_name('token_value_head.py')),
                weights={n:v[1] for n,v in FILES.items()}, width=WIDTH)


def build_bank(args):
    _, _, texts, opened = text_inputs(args)
    key = header(texts)
    args.cache.mkdir(parents=True, exist_ok=True)
    path = args.cache/'tokens.npz'
    if (args.cache/'receipt.json').exists():
        receipt = read(args.cache/'receipt.json')
        require(receipt['key'] == key and digest(path) == receipt['sha256'], 'Stale token cache')
        return
    usage = extract(texts, args.weights, path)
    write(args.cache/'receipt.json', dict(key=key, sha256=digest(path), usage=usage, training_members=opened))


def logits(model, rows):
    require(np.array_equal(model.classes_, [0, 1]), 'Expected binary preference classes')
    return np.asarray(model.classifier.decision_function(model.features(rows))).reshape(-1)


def crossfit(rows, labels, groups, cache):
    split = StratifiedGroupKFold(n_splits=2, shuffle=True, random_state=SEED)
    offsets = np.full(len(labels), np.nan)
    parts = []
    for fresh, held in split.split(np.zeros(len(labels)), labels, groups):
        require(not set(groups[fresh]) & set(groups[held]), 'A title occurs in both base fitting and offset observations')
        model = MiniLMTextClassifier('pair_text', 'cached-only', False)
        model.encoder = cache
        model.fit(take(rows, fresh), labels[fresh])
        offsets[held] = logits(model, take(rows, held))
        parts.append(dict(fitting=len(fresh), held=len(held), fitting_groups=len(set(groups[fresh])),
                          observations_groups=len(set(groups[held]))))
    require(np.isfinite(offsets).all(), 'Missing out-of-fit offsets')
    return offsets, parts


def fit(args):
    data, splits, texts, _ = text_inputs(args)
    rec = read(args.cache/'receipt.json')
    require(rec['key'] == header(texts) and rec['sha256'] == digest(args.cache/'tokens.npz'), 'Stale token bank')
    bank = Bank(args.cache/'tokens.npz')
    groups = sample_groups(data, 'shared_text')
    torch.set_num_threads(2)
    seals = []
    with threadpool_limits(limits=1):
        for i, split in enumerate(splits):
            dest = args.out/f'fold_{i}'
            dest.mkdir(exist_ok=True)
            train, outer = map(np.asarray, (split['train'], split['outer']))
            require(not set(groups[train]) & set(groups[outer]), 'A title occurs on both sides of outer evaluation')
            rows, later = take(data.X_train, train), take(data.X_train, outer)
            target = data.y_train[train]
            folder = source(args, i)
            ordinary = joblib.load(folder/'selected_model.joblib')['model']
            require(type(ordinary) is MiniLMTextClassifier, 'An ordinary independent L6 incumbent is required')
            outer_cache = CachedVectors(folder.parent/(args.arm+'_prediction_features'))
            ordinary.encoder = outer_cache
            base = logits(ordinary, later)
            before, stronger = [read(p/f'fold_{i}/outer_predictions.json') for p in (args.reference, args.strong)]
            require(before['rows'] == stronger['rows'] == outer.tolist(), 'Baseline sample order mismatch')
            decisions = {'default':before[args.arm], 'strong':stronger[args.strong_arm]}
            np.testing.assert_array_equal(base > 0., decisions['default'])
            started = time.monotonic()
            inner_cache = CachedVectors(folder)
            offsets, parts = crossfit(rows, target, groups[train], inner_cache)
            baseline_seconds = time.monotonic()-started
            fit_pairs, query_pairs = bank.pairs(rows), bank.pairs(later)
            arms = {}
            for name in MODES:
                started = time.monotonic()
                query, value = fit_head(bank, fit_pairs, offsets, target, name)
                path = dest/(name+'.npz')
                np.savez(path, query=query.numpy(), value=value.numpy())
                with np.load(path) as saved:
                    q = torch.from_numpy(saved['query'])
                    v = torch.from_numpy(saved['value'])
                residual = predict_delta(bank, query_pairs, q, v, name)
                reverse = predict_delta(bank, query_pairs[:16, ::-1], q, v, name)
                np.testing.assert_allclose(reverse, -residual[:16], atol=1e-5)
                decisions[name] = (base+residual > 0.).astype(int).tolist()
                arms[name] = dict(seconds=time.monotonic()-started, weights=digest(path),
                                  parameters=WIDTH * (1 if name == 'mean' else 2),
                                  optimizer_steps=EPOCHS * ((len(rows)+BATCH-1)//BATCH))
            write(dest/'predictions.json', dict(rows=outer.tolist(), arms=decisions))
            seals.append(dict(predictions=digest(dest/'predictions.json'), calibrations=parts, arms=arms,
                              offset_seconds=baseline_seconds, cache_lookups=outer_cache.lookups+inner_cache.lookups))
            print('sealed fold', i+1, flush=True)
    write(args.out/'sealed.json', dict(folds=seals, protocol_sha256=digest(args.out/'protocol.json'),
                                      features_sha256=digest(args.cache/'receipt.json')))


def score(args):
    data, splits, _, opened = text_inputs(args)
    seals = read(args.out/'sealed.json')
    require(seals['protocol_sha256'] == digest(args.out/'protocol.json') and
            seals['features_sha256'] == digest(args.cache/'receipt.json'), 'Changed sources')
    folds = []
    controls = ('default', 'strong', 'mean', 'permuted')
    for i, (split, seal) in enumerate(zip(splits, seals['folds'], strict=True)):
        path = args.out/f'fold_{i}/predictions.json'
        require(seal['predictions'] == digest(path), 'Changed predictions')
        batch = read(path)
        require(batch['rows'] == split['outer'], 'Different outer rows')
        truth = data.y_train[batch['rows']]
        masks = {a:np.asarray(pred)==truth for a,pred in batch['arms'].items()}
        effect = {a:dict(corrected=int((masks['learned'] & ~masks[a]).sum()), lost=int((~masks['learned'] & masks[a]).sum()))
                  for a in controls}
        folds.append(dict(rows=len(truth), correct={a:int(m.sum()) for a,m in masks.items()}, paired=effect))
    n = sum(f['rows'] for f in folds)
    total = {a:sum(f['correct'][a] for f in folds) for a in folds[0]['correct']}
    wins = {a:sum(f['correct']['learned'] > f['correct'][a] for f in folds) for a in controls}
    write(args.out/'results.json', dict(rows=n, correct=total, folds=folds, wins=wins,
          qualified=all(total['learned']-total[a] >= .002*n and wins[a] >= 3 for a in controls),
          new_logistic_fits=2*len(folds), new_supervised_heads=len(MODES)*len(folds),
          feature_usage=read(args.cache/'receipt.json')['usage'], new_llm_calls=0, incremental_rmb=0,
          training_members=opened, seals_sha256=digest(args.out/'sealed.json')))
    print(total, wins)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze', 'encode', 'fit', 'score'))
    for arg in ('archive', 'reference', 'strong', 'out', 'cache', 'weights'):
        parser.add_argument('--'+arg, type=Path, required=True)
    parser.add_argument('--arm', default='auto')
    parser.add_argument('--strong-arm', default='encoder-mixture-wide')
    args = parser.parse_args()
    if args.phase == 'freeze':
        args.out.mkdir(parents=True, exist_ok=False)
    else:
        require((args.out/'protocol.json').is_file(), 'Freeze first')
    freeze_file(args.out/'protocol.json', frozen(args))
    if args.phase == 'encode':
        build_bank(args)
    elif args.phase == 'fit':
        require(not (args.out/'sealed.json').exists(), 'Already sealed')
        fit(args)
    elif args.phase == 'score':
        score(args)
