"""Two experiment slots for structures suggested by the fitting data and actual errors."""
import math

import numpy as np


SEARCH = 'structure-search'
FIXED = 'structure-fixed'
CROP_CONTROL = 'structure-crop-control'
MODES = (SEARCH, FIXED, CROP_CONTROL)
PAIRS = 'supported_field_interactions'
MORE_PAIRS = 'broader_supported_field_interactions'
LOCAL_TREE = 'locally_branching_category_tree'
EDITS = 'minilm_changed_passage_views'
CENTER = 'minilm_centered_passage_views'
ROUTES = {
    PAIRS: 'selected_field_interactions',
    MORE_PAIRS: 'selected_field_interactions',
    LOCAL_TREE: 'locally_branching_tree',
    EDITS: 'passage_views',
    CENTER: 'passage_views',
}


def table_options(x, y, incumbent):
    from .field_interactions import rank_pairs, choose_pairs
    if not incumbent['candidate'].startswith('catboost_depth') or not 2 <= x.shape[1] <= 40 or not 200 <= len(y) <= 30000:
        return {}, {}
    ranking = rank_pairs(x, y)
    qualified = choose_pairs(ranking, len(ranking))
    base = dict(backbone=incumbent['candidate'], backbone_params=incumbent['params'])
    facts = dict(eligible_interactions=len(qualified), strongest=ranking[:3])
    menu = {PAIRS: dict(base, pair_limit=3), LOCAL_TREE: dict(base, grow_policy='Depthwise',
                                                               min_data_in_leaf=max(16, math.ceil(len(y) / 200)))}
    if len(qualified) > 3:
        menu[MORE_PAIRS] = dict(base, pair_limit=8)
    return menu, facts


def text_options(rows, mini):
    from .edit_views import focus_pair
    sampled = [rows[i] for i in np.linspace(0, len(rows) - 1, min(256, len(rows)), dtype=int)]
    cropped = sum(focus_pair(a, b)[1] for a, b in sampled)
    return ({name: dict(mini, passage_control=name == CENTER) for name in (EDITS, CENTER)},
            dict(sampled_pairs=len(sampled), cropped_pairs=int(cropped)))


def propose(mode, evidence, feasible, used, small_encoder):
    facts = evidence['structure']
    helped = evidence['corrected'] - evidence['lost']
    noise = math.sqrt(max(1, evidence['corrected'] + evidence['lost']))
    if evidence['kind'] == 'categorical_tabular' and PAIRS in feasible:
        if mode == FIXED:
            return ((PAIRS if not used else LOCAL_TREE), 'The fixed arm offers field interactions, then a locally branching tree.')
        if evidence['shared_errors'] < evidence['required_shared_errors']:
            return None, 'Too few shared errors to allocate a special trial.'
        if not used:
            if facts['eligible_interactions']:
                return PAIRS, 'Some field pairs improve held-out log likelihood in both training-group halves. Test them on the leading tree.'
            return LOCAL_TREE, 'No field pair improved both halves. Allow different branches to split on different fields.'
        if used[-1] == PAIRS and helped >= noise and MORE_PAIRS in feasible:
            return MORE_PAIRS, 'The initial interactions gained paired decisions. Include more supported pairs.'
        if LOCAL_TREE not in used:
            return LOCAL_TREE, 'The preceding evidence gives insufficient support to expand the interactions. Test different tree geometry.'
        return None, 'No further supported structural change. Return the slot to ordinary search.'
    if evidence['kind'] == 'pair_text' and small_encoder in feasible:
        if not used:
            if mode != FIXED and evidence['shared_errors'] < evidence['required_shared_errors']:
                return None, 'Too few shared errors for another text representation.'
            return small_encoder, 'Measure whole-item sentence features alongside the existing lexical model.'
        offer = CENTER if mode == CROP_CONTROL else EDITS
        if used[-1] != small_encoder or offer not in feasible:
            return None, 'No completed whole-item experiment supports a passage comparison.'
        if mode != FIXED and (helped < -noise or facts.get('cropped_pairs', 0) < .20 * facts.get('sampled_pairs', 1)
                              or evidence['shared_errors'] < evidence['required_shared_errors']):
            return None, 'Whole-item accuracy or the observed coverage does not support a second view.'
        return offer, ('Use a centred crop of the same observed length.' if offer == CENTER else
                       'Retain whole texts and test an additional semantic view of their changed passages.')
    return None, 'No applicable structure experiment.'
