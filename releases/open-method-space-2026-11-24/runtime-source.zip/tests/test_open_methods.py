import copy
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from superagent.ab_method_search import rank
from superagent.open_methods import MethodSpace,capability,discovered,materialize,propose,resolve
from superagent.task_semantics import candidate_swap_rule


def contract(kind='numeric_tabular',metric='accuracy',semantics=None):
    return dict(kind=kind,metric=dict(name=metric,labels=[0,1],direction='maximize'),
                input_schema={'pair_semantics':semantics} if semantics else {})


def profile(rows=250):
    return dict(statistics=dict(train_rows=rows,feature_shape=[12]),majority_class_fraction=.6,minority_class_fraction=.4)


class TestOpenMethods(unittest.TestCase):
    def test_installed_inventory_and_feedback_generate_new_configs(self):
        task=contract()
        p=profile()
        first,summary=propose(task,p,[])
        self.assertEqual(summary['inventory'],sorted(discovered()))
        self.assertEqual(set(summary['inventory']),set(summary['excluded'])|{s['class'] for s in first.values()})
        def history(train):
            return [dict(trial=1,status='completed',split_id='primary',search_score=.71,train_score=train)]
        high_gap,high_reason=propose(task,p,history(.98))
        low_gap,low_reason=propose(task,p,history(.73))
        self.assertNotEqual(set(high_gap),set(low_gap))
        self.assertGreater(high_reason['gap'],low_reason['gap'])
        self.assertTrue(set(high_gap)-set(first))
        renamed=copy.deepcopy(task)
        renamed.update(task_name='arbitrary string',dataset_name='unseen other object')
        renamed['input_schema']['columns']=[{'name':'different field name'}]
        self.assertEqual(propose(renamed,p,history(.98)),(high_gap,high_reason))

    def test_probability_capabilities_and_pair_semantics(self):
        for sem in ('symmetric','preference'):
            specs,info=propose(contract('pair_text','roc_auc',sem),profile(),[])
            self.assertTrue(specs)
            for spec in specs.values():
                c=materialize(spec)
                self.assertTrue(capability(spec)['supports_probabilities'])
                self.assertEqual(candidate_swap_rule(c),'preserves' if sem=='symmetric' else 'flips')
            self.assertIn('LinearSVC',info['excluded'])

    def test_registry_is_content_addressed_and_previously_tested_configs_survive(self):
        p=profile()
        with TemporaryDirectory() as d:
            space=MethodSpace(contract(),p,Path(d))
            initial,gen0=space.refresh([], {})
            self.assertTrue(gen0['newly_seen'])
            candidate=next(iter(initial))
            row=dict(candidate=candidate,trial=1,split_id='primary',status='completed',search_score=.55,train_score=.99)
            updated,gen1=space.refresh([row],{})
            self.assertIn(candidate,updated)
            self.assertTrue(gen1['newly_seen'])
            import json
            document=json.loads((Path(d)/gen0['file']).read_text())
            self.assertEqual(resolve('numeric_tabular',candidate,document).family,candidate)
            spec=document['entries'][candidate]
            spec['dimensions']=3 if spec['dimensions']!=3 else 4
            with self.assertRaises(ValueError):
                resolve('numeric_tabular',candidate,document)

    def test_reordering_new_and_old_methods_does_not_change_the_choice(self):
        specs,_=propose(contract(),profile(),[])
        caps={n:capability(s) for n,s in specs.items()}
        state=dict(training_profile=profile(),prediction_evidence=[])
        result=rank(state,caps,list(caps),[])
        self.assertEqual(rank(state,dict(reversed(caps.items())),list(reversed(caps)),[]),result)


if __name__=='__main__':
    unittest.main()
