"""Frozen, order-equivariant contextual features for a declared pairwise preference."""
import time
from pathlib import Path

import numpy as np

from .minilm_features import FILES, MODEL
from .pretrained_choice import acquire


class PairAttentionEncoder:
    def __init__(self, weights):
        import torch
        from tokenizers import Tokenizer
        from transformers import BertModel

        weights=Path(weights)
        acquire(weights, MODEL, FILES)
        self.tokenizer=Tokenizer.from_file(str(weights/'tokenizer.json'))
        self.tokenizer.no_padding()
        self.tokenizer.enable_truncation(max_length=256)
        torch.set_num_threads(min(3,torch.get_num_threads()))
        self.model,info=BertModel.from_pretrained(str(weights),use_safetensors=True,local_files_only=True,
                     add_pooling_layer=False,attn_implementation='eager',output_loading_info=True)
        if info['missing_keys'] or info['mismatched_keys'] or info['error_msgs']:
            raise ValueError('Unexpected initialization of the pinned MiniLM checkpoint')
        self.model.eval().requires_grad_(False)
        self.usage={mode:dict(batches=0,input_tokens=0,padded_positions=0,pairs=0,seconds=0.)
                    for mode in ('blocked','joint')}

    def difference(self,pairs,mode):
        """Reset positions on each side, then change only whether tokens may attend to the other item."""
        import torch
        if mode not in self.usage or not pairs:
            raise ValueError('Supply a nonempty pair sequence and a declared attention mode')
        unique=dict.fromkeys(t for pair in pairs for t in pair)
        tokenized={t:item.ids for t,item in zip(unique,self.tokenizer.encode_batch(list(unique)),strict=True)}
        lengths=[len(tokenized[a])+len(tokenized[b]) for a,b in pairs]
        order=np.argsort(lengths,kind='stable')
        result=np.empty((len(pairs),self.model.config.hidden_size),dtype=np.float32)
        usage=self.usage[mode]
        started=time.monotonic()
        with torch.inference_mode():
            for off in range(0,len(order),32):
                batch=order[off:off+32]
                shape=(len(batch),max(lengths[i] for i in batch))
                inputs=torch.zeros(shape,dtype=torch.long)
                positions=torch.zeros_like(inputs)
                side=torch.full_like(inputs,-1)
                for j,idx in enumerate(batch):
                    a,b=(tokenized[t] for t in pairs[idx])
                    na,nb=len(a),len(b)
                    inputs[j,:na+nb]=torch.tensor(a+b)
                    positions[j,:na]=torch.arange(na)
                    positions[j,na:na+nb]=torch.arange(nb)
                    side[j,:na]=0
                    side[j,na:na+nb]=1
                keys=(side!=-1)[:,None,:].expand(-1,shape[1],-1)
                mask=(keys & (side[:,:,None]==side[:,None,:])) if mode=='blocked' else keys
                hidden=self.model(input_ids=inputs,position_ids=positions,attention_mask=mask.to(torch.int64)).last_hidden_state
                pooled=[]
                for role in (0,1):
                    weights=(side==role).unsqueeze(-1)
                    mean=(hidden*weights).sum(1)/weights.sum(1)
                    pooled.append(torch.nn.functional.normalize(mean,dim=1))
                result[batch]=(pooled[0]-pooled[1]).numpy()
                tokens=int(sum(lengths[i] for i in batch))
                usage['batches']+=1
                usage['pairs']+=len(batch)
                usage['input_tokens']+=tokens
                usage['padded_positions']+=inputs.numel()-tokens
        usage['seconds']+=time.monotonic()-started
        if not np.isfinite(result).all():
            raise ValueError('Nonfinite pair representation')
        return result
