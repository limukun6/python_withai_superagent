"""Check five additional task contracts at the native prediction boundary using one open planner."""
import argparse
import csv
import io
import json
from pathlib import Path
import zipfile

import numpy as np

from scripts.run_b_open_methods import ROOT,SEED,audit,cli,export,read,require,save
from superagent.ab_run import sha,sources
from superagent.data import load_development_task


SLOTS=('t0','t1','t2','t3','t4')
PLAN=ROOT/'docs/batches/B_open_input_contracts_20261124_zh.md'


def fixtures(slot,start,n):
    rows=[]
    for i in range(start,start+n):
        value=(17*i+3)%23
        band=('low','middle','high')[i%3]
        label=('a','b','c')[(value+i)%3]
        if slot=='t0':
            row=[band,str(value),'unseen' if start and i%5==0 else str(i%4)]
        elif slot=='t1':
            row=['' if i%17==0 else str(value),band,'new' if start and i%5==0 else str(i%4)]
        else:
            left=f'case {i} {band} wide river south'
            right=f'part {i} {value} narrow trail north'
            if value%2:
                left,right=right,left
            row=[left,right]
            if slot=='t3':
                label=int((i+value)%3!=0)
            elif slot=='t4':
                label=int(left.startswith('case'))
        rows.append((row,label))
    return rows


def package(file,slot,training):
    rows=fixtures(slot,0,150) if training else fixtures(slot,500,12 if slot in ('t3','t4') else 24)
    if not training and slot in ('t3','t4'):
        rows=[v for row,y in rows for v in ((row,y),(row[::-1],y if slot=='t3' else 1-y))]
    types=({'t0':['categorical']*3,'t1':['numeric','categorical','categorical']}.get(slot) or ['text','text'])
    names=[f'x{i}' for i in range(len(types))]
    manifest=dict(schema_version=1,objective='classification',modality='tabular' if slot in ('t0','t1') else 'pair_text',
                  columns=[dict(name=n,type=t) for n,t in zip(names,types)],target='y',
                  metric='roc_auc' if slot=='t1' else 'macro_f1' if slot=='t2' else 'accuracy',
                  splits={('train' if training else 'test'):dict(format='csv',path='rows.csv')})
    semantics={'t2':'relation','t3':'symmetric','t4':'preference'}.get(slot)
    if semantics:
        manifest['pair_semantics']=semantics
    if slot in ('t3','t4'):
        manifest['pair_label_one']='equivalent' if slot=='t3' else 'left'
    stream=io.StringIO(newline='')
    writer=csv.writer(stream)
    writer.writerow(names+(['y'] if training else []))
    writer.writerows([*x,*([y] if training else [])] for x,y in rows)
    with zipfile.ZipFile(file,'x') as z:
        for name,content in (('manifest.json',json.dumps(manifest)),('rows.csv',stream.getvalue())):
            info=zipfile.ZipInfo(name,(2020,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,content.encode())


def run(out):
    if not (out/'protocol.json').exists():
        out.mkdir(parents=True,exist_ok=False)
        tasks={}
        for slot in SLOTS:
            folder=out/'inputs'/slot
            folder.mkdir(parents=True)
            package(folder/'train.zip',slot,True)
            package(folder/'features.zip',slot,False)
            task=load_development_task(folder/'train.zip')
            tasks[slot]=dict(kind=task.kind,metric=task.spec['metric'],train_rows=len(task.y_train),outer_rows=24,
                             files={v.name:sha(v) for v in folder.iterdir()})
        save(out/'protocol.json',dict(seed=SEED,tasks=tasks,source=sources(),plan=sha(PLAN),runner=sha(Path(__file__)),
                                      fit_limit=4,api_limit=0))
    p=read(out/'protocol.json')
    require(p['source']==sources() and p['plan']==sha(PLAN) and p['runner']==sha(Path(__file__)),'Contract source changed')
    sealed={}
    for slot in SLOTS:
        folder=out/(slot+'_open')
        archive=out/'inputs'/slot/'train.zip'
        require(sha(archive)==p['tasks'][slot]['files']['train.zip'],'Changed training input')
        if not (folder/'agent/run_outcome.json').exists():
            folder.mkdir(exist_ok=False)
            cli(['run',archive,'--scheduler','ab-v1','--planner','local','--portfolio','ab-v1','--task-profile','train',
                 '--local-method-search','open','--fit-limit',4,'--seed',SEED,'--time-limit',600,'--trial-timeout',180,
                 '--run-dir',folder/'agent'],folder/'physical.jsonl',folder/'train.log',650)
        record=audit(out,slot,'open',4)
        save(folder/'receipt.json',record)
        sealed[slot]=sha(folder/'receipt.json')
        print(slot,'sealed',record['winner'],record['actual_fits'],flush=True)
    save(out/'models_frozen.json',sealed)
    results={}
    for slot in SLOTS:
        folder=out/(slot+'_open')
        require(sha(folder/'receipt.json')==sealed[slot] and sha(out/'inputs'/slot/'features.zip')==p['tasks'][slot]['files']['features.zip'],
                'Contract export input changed')
        checks=[export(out,slot,'open',i,24) for i in range(2)]
        require(checks[0]==checks[1],'Fresh process exports differ')
        with (folder/'export_0/rows.csv').open() as stream:
            rows=list(csv.DictReader(stream))
        require([r['row_id'] for r in rows]==list(map(str,range(24))),'Prediction order changed')
        labels=[row['prediction'] for row in rows]
        extra={}
        if slot=='t1':
            manifest=read(folder/'export_0/prediction_manifest.json')
            classes=manifest['score_class_order']
            mat=np.array([[float(row[f'score_{i}']) for i in range(len(classes))] for row in rows])
            require(classes==['a','b','c'] and np.isfinite(mat).all() and (mat>=0).all() and (mat<=1).all()
                    and np.allclose(mat.sum(axis=1),1.),'Invalid multiclass probabilities')
            extra=dict(classes=classes,normalized_probability_rows=len(mat))
        if slot in ('t3','t4'):
            matching=sum((a==b) if slot=='t3' else (a!=b) for a,b in zip(labels[::2],labels[1::2]))
            extra=dict(swap_cases=12,swap_contract_satisfied=matching)
        results[slot]=dict(**extra,predictions=checks,rows=len(rows),model=read(folder/'receipt.json')['winner'])
    save(out/'results.json',results)
    save(out/'completion.json',{n:sha(out/(n+'.json')) for n in ('protocol','models_frozen','results')})
    print(json.dumps(results),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=lambda v:Path(v).resolve(),required=True)
    run(parser.parse_args().out)
