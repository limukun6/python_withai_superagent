"""A local estimate of the errors of a frozen binary classifier, learned on out-of-fit rows."""
import numpy as np
from scipy.sparse import issparse
from sklearn.model_selection import GroupKFold, GroupShuffleSplit

from .error_specialist import paired_effect


SEED=113129


def neighbors(context, direction, residual, reference, query, shuffled):
    """Disjoint reference/query row indices are supplied by the grouped fitting protocol."""
    if len(reference)==0 or set(reference) & set(query):
        raise ValueError('A query must be outside the residual memory')
    linked=(np.random.default_rng(SEED).permutation(reference) if shuffled else reference)
    k=min(len(reference),max(4,int(np.sqrt(len(reference)))))
    estimates=[]
    for offset in range(0,len(query),64):
        ids=query[offset:offset+64]
        similarity=context[ids] @ context[reference].T
        if issparse(similarity):
            similarity=similarity.toarray()
        order=np.argsort(-similarity,axis=1,kind='stable')[:,:k]
        values=np.take_along_axis(similarity,order,axis=1)
        weights=np.exp((values-values[:,:1])/.10)
        weights/=weights.sum(axis=1,keepdims=True)
        sources=linked[order]
        if direction is not None:
            weights*=np.einsum('ij,ikj->ik',direction[ids],direction[sources])
        estimates.extend(np.sum(weights*residual[sources],axis=1))
    return np.asarray(estimates)


def fit_memory(context,direction,base_prob,truth,groups,shuffled=False):
    truth,groups,base_prob=map(np.asarray,(truth,groups,base_prob))
    if (truth.shape!=groups.shape or truth.shape!=base_prob.shape or len(context.shape)!=2
            or context.shape[0]!=len(truth) or not np.isin(truth,[0,1]).all()
            or not np.isfinite(base_prob).all() or np.any((base_prob<0)|(base_prob>1))):
        raise ValueError('Misaligned residual inputs')
    if len(np.unique(groups))<16:
        return dict(accepted=False,alpha=0.,reason='insufficient groups')
    delta=truth-base_prob
    discovery,check=next(GroupShuffleSplit(n_splits=1,test_size=.4,random_state=SEED).split(base_prob,groups=groups))
    cross=np.empty(len(discovery))
    for fit,held in GroupKFold(n_splits=2).split(discovery,groups=groups[discovery]):
        cross[held]=neighbors(context,direction,delta,discovery[fit],discovery[held],shuffled)
    xx=float(cross@cross)
    alpha=float(np.clip(cross@delta[discovery]/xx,0.,2.)) if xx>0 else 0.
    correction=neighbors(context,direction,delta,discovery,check,shuffled)
    base=base_prob[check]
    proposed=np.clip(base+alpha*correction,0.,1.)
    effect=paired_effect(truth[check],base>.5,proposed>.5,groups[check])
    se=effect['group_se_rows']
    accept=alpha>0 and se is not None and effect['net']>=max(.002*len(check),se)
    return dict(accepted=bool(accept),alpha=alpha,discovery_rows=len(discovery),confirmation=effect,
                brier_gain=float(np.mean((truth[check]-base)**2-(truth[check]-proposed)**2)))
