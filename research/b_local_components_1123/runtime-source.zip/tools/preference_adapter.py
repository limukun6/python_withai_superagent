"""Train one small residual adapter inside the last frozen encoder block or after sentence pooling."""
import math
import time

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from superagent.pair_attention import PairAttentionEncoder
from tools.token_value_head import text_key


SEED = 78101
RANK = 8
EPOCHS = 3
BATCH = 96
MODES = ('head', 'pooled', 'inside')


def last_sentence(layer, states, present):
    mask = (~present[:, None, None, :]).float() * torch.finfo(torch.float32).min
    final = layer(states, attention_mask=mask)[0]
    pooled = (final * present[:, :, None]).sum(1) / present.sum(1, keepdim=True)
    return F.normalize(pooled, dim=1)


def encode_items(texts, folder, output):
    started = time.monotonic()
    transformer = PairAttentionEncoder(folder)
    encoded = transformer.tokenizer.encode_batch(texts)
    lengths = np.array([len(t.ids) for t in encoded])
    offsets = np.r_[0, lengths.cumsum()]
    order = np.argsort(lengths, kind='stable')
    hidden = np.empty((offsets[-1], 384), dtype='float16')
    full = np.empty((len(texts), 384), dtype='float32')
    restored = np.empty_like(full)
    padded = 0
    with torch.inference_mode():
        for start in range(0, len(order), 64):
            ids = order[start:start+64]
            width = int(lengths[ids].max())
            inputs = torch.zeros((len(ids),width),dtype=torch.long)
            present = torch.zeros_like(inputs, dtype=torch.bool)
            for i, idx in enumerate(ids):
                inputs[i, :lengths[idx]] = torch.tensor(encoded[idx].ids)
                present[i, :lengths[idx]] = True
            output_states = transformer.model(input_ids=inputs,attention_mask=present.long(),output_hidden_states=True)
            penultimate = output_states.hidden_states[-2].half()
            native = (output_states.last_hidden_state*present[:,:,None]).sum(1)/present.sum(1,keepdim=True)
            full[ids] = F.normalize(native,dim=1).numpy()
            restored[ids] = last_sentence(transformer.model.encoder.layer[-1],penultimate.float(),present).numpy()
            for j,idx in enumerate(ids):
                hidden[offsets[idx]:offsets[idx+1]] = penultimate[j,:lengths[idx]].numpy()
            padded += int(inputs.numel()-lengths[ids].sum())
    error = float(np.max(np.abs(restored-full)))
    if not np.isfinite(hidden).all() or not np.isfinite(error) or error >= .001:
        raise ValueError('Cached penultimate states do not reproduce the original sentence encoder')
    np.savez(output, keys=[text_key(t) for t in texts], offsets=offsets, states=hidden, full=full, restored=restored)
    return dict(unique_items=len(texts), input_tokens=int(offsets[-1]), padded_positions=padded,
                full_encoder_batches=math.ceil(len(texts)/64), extra_last_block_batches=math.ceil(len(texts)/64),
                seconds=time.monotonic()-started, storage_dtype='float16', max_reconstruction_error=error)


class HiddenBank:
    def __init__(self,path):
        with np.load(path) as data:
            self.keys={k:i for i,k in enumerate(data['keys'])}
            self.offsets, self.hidden = data['offsets'], data['states']
            self.full, self.restored = map(torch.from_numpy,(data['full'],data['restored']))

    def pairs(self,rows):
        return np.asarray([[self.keys[text_key(s)] for s in pair] for pair in rows],dtype=int)

    def states(self,items):
        lengths = self.offsets[items+1] - self.offsets[items]
        positions = np.arange(lengths.max())[None,:]
        mask = positions < lengths[:,None]
        source = self.offsets[items,None] + np.minimum(positions, lengths[:,None]-1)
        return torch.from_numpy(self.hidden[source].astype('float32')), torch.from_numpy(mask)


class PreferenceAdapter(nn.Module):
    def __init__(self,mode):
        super().__init__()
        if mode not in MODES:
            raise ValueError('Unknown adapter position')
        self.mode = mode
        self.direction = nn.Parameter(torch.zeros(384))
        if mode != 'head':
            self.down = nn.Linear(384,RANK,bias=False)
            self.up = nn.Linear(RANK,384,bias=False)
            nn.init.zeros_(self.up.weight)

    def update(self,x):
        return self.up(F.gelu(self.down(x)))

    def forward(self,bank,pairs,base_coefficients,last_layer):
        items = pairs.ravel()
        old = bank.full[items]
        if self.mode == 'inside':
            states,present = bank.states(items)
            adapted = states + self.update(F.layer_norm(states, (384,)))
            new = old + (last_sentence(last_layer,adapted,present) - bank.restored[items])
        elif self.mode == 'pooled':
            scaled = old * math.sqrt(384)
            new = F.normalize(scaled + self.update(scaled), dim=1)
        else:
            new = old
        old_diff = old[::2] - old[1::2]
        new_diff = new[::2] - new[1::2]
        return ((new_diff - old_diff) * base_coefficients).sum(1) + new_diff @ self.direction


def train_adapter(mode,bank,pairs,offset,coefs,y,layer):
    torch.manual_seed(SEED)
    learner = PreferenceAdapter(mode)
    optimizer = torch.optim.AdamW(learner.parameters(),lr=.001,weight_decay=.01)
    generator = np.random.default_rng(SEED)
    base = torch.from_numpy(np.asarray(offset,dtype='float32'))
    coeff = torch.from_numpy(np.asarray(coefs,dtype='float32'))
    truth = torch.from_numpy(np.asarray(y,dtype='float32'))
    losses=[]
    for _ in range(EPOCHS):
        order = generator.permutation(len(y))
        aggregate = 0.
        for start in range(0,len(order),BATCH):
            idx = order[start:start+BATCH]
            delta = learner(bank,pairs[idx],coeff[idx],layer)
            loss = F.binary_cross_entropy_with_logits(base[idx]+delta,truth[idx]) + .10*delta.square().mean()
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(learner.parameters(),1.)
            optimizer.step()
            aggregate += float(loss.detach())*len(idx)
        losses.append(aggregate/len(order))
    if not np.isfinite(losses).all():
        raise ValueError('Nonfinite supervised adaptation')
    return learner.eval(), losses


def predict(learner,bank,pairs,coeff,layer):
    coefs = torch.from_numpy(np.asarray(coeff,dtype='float32').copy()).reshape(1,-1)
    with torch.inference_mode():
        return np.concatenate([learner(bank,pairs[i:i+BATCH],coefs,layer).numpy() for i in range(0,len(pairs),BATCH)])
