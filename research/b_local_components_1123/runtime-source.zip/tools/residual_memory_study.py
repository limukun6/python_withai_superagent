"""Replay two modalities with one residual-retrieval decision and a sham memory."""
import argparse
import hashlib
import sqlite3
from pathlib import Path

import joblib
import numpy as np
from scipy.sparse import vstack as sparse_stack
from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import normalize
from threadpoolctl import threadpool_limits

from superagent.minilm_features import MiniLMTextClassifier
from superagent.models import probability_with_model
from superagent.prediction_evidence import fingerprint
from superagent.pretrained_choice import digest
from superagent.residual_memory import fit_memory,neighbors
from superagent.splits import take
from tools.error_specialist_study import CASES, require, source_data
from tools.pretrained_study import read,write
from tools.soft_vote_diagnostic import freeze_file


class CachedVectors:
    """The experiment has no encoder implementation or network fallback."""
    def __init__(self,folder):
        path=folder/'minilm_category_vectors.sqlite'
        with sqlite3.connect(path.resolve().as_uri()+'?mode=ro&immutable=1',uri=True) as db:
            self.values={k:np.frombuffer(v,dtype='<f4') for k,v in db.execute('SELECT id,v FROM vectors')}
        self.lookups=0

    def encode(self,texts):
        texts=list(texts)
        self.lookups+=len(texts)
        return np.stack([self.values[hashlib.sha256(text.encode()).hexdigest()] for text in texts])


def probabilities(kind,bundle,rows,cache):
    model=bundle['model']
    if isinstance(model,MiniLMTextClassifier):
        require(cache is not None,'The trained text classifier needs an audited feature store')
        model.encoder=cache
    classes,values=probability_with_model(kind,model,rows)
    require(np.array_equal(classes,[0,1]) and len(values)==len(rows) and np.isfinite(values).all()
            and np.allclose(values.sum(axis=1),1.),'Invalid binary probabilities')
    return values[:,1]


def memory_coordinates(kind,train,query,inner_cache,outer_cache):
    if kind=='categorical_tabular':
        def cells(rows):
            return [{f'{i}={str(v).strip().casefold()}':1. for i,v in enumerate(row)} for row in rows]
        vectorizer=DictVectorizer(dtype=np.float32)
        a=normalize(vectorizer.fit_transform(cells(train)))
        b=normalize(vectorizer.transform(cells(query)))
        return sparse_stack((a,b),format='csr'),None
    if kind=='pair_text':
        def parts(rows,cache):
            x=cache.encode([s for row in rows for s in row])
            return normalize(x[::2]+x[1::2]),normalize(x[::2]-x[1::2])
        ca,da=parts(train,inner_cache)
        cb,db=parts(query,outer_cache)
        return np.vstack((ca,cb)),np.vstack((da,db))
    raise ValueError('The residual-memory pilot requires an implemented coordinate adapter')


def frozen(args):
    root=Path(__file__).resolve().parents[1]
    sources={}
    for case in CASES:
        ref=args.ref/('release-auto-'+case)
        protocol=read(ref/'protocol.json')
        require(protocol['archive_sha256']==digest(getattr(args,case)) and protocol['fold_numbers']==[1,2,3,4,5],
                'Incorrect reference or archive')
        files=['protocol.json']
        for i in range(5):
            fold=ref/f'fold_{i}'
            run=fold/'auto'
            selected=read(run/'confirmation.json')['selected_candidate']
            number,=[r['trial'] for r in read(run/'trials.json') if r['candidate']==selected]
            members=['selected_model.joblib','final_selection.json','trials.json','confirmation.json','split.json',
                     'confirmation_split_1.json','confirmation_split_2.json',f'trial_{number}.joblib',
                     f'confirmation_1_{number}.joblib',f'confirmation_2_{number}.joblib']
            files.extend(f'fold_{i}/auto/'+name for name in members)
            files.append(f'fold_{i}/outer_predictions.json')
            if read(run/'task_spec.json')['model_kind']=='pair_text':
                files.extend(f'fold_{i}/{part}/minilm_category_vectors.sqlite' for part in ('auto','auto_prediction_features'))
        sources[case]={f:digest(ref/f) for f in files}
    return dict(sources=sources,code={p:digest(root/p) for p in ('tools/residual_memory_study.py',
                    'superagent/residual_memory.py','superagent/error_specialist.py','tools/error_specialist_study.py')},
                rule='Estimate prediction-probability residuals only where a retained model or real probability '
                     'array exists; omit confirmation artifacts containing only hard predictions and log coverage. Use normalized '
                     'field match or mean sentence vectors for nearest neighbours. For preferences, align residuals '
                     'by the dot product of normalized difference vectors. Learn a nonnegative strength by '
                     'grouped two-fold discovery, check once on disjoint groups, then use all eligible inner rows. '
                     'The placebo disconnects contexts from their residuals and directions without altering marginals. '
                     'Freeze all outer predictions before scoring. Encoder caches are read-only.',
                promotion='Per task gain >=0.2pp and at least three strict fold wins against incumbent and sham. '
                          'If qualified, repeat on a different grouped split.')


def inner_probabilities(data,groups,train_ids,run,cache):
    selected=read(run/'confirmation.json')['selected_candidate']
    number,=[r['trial'] for r in read(run/'trials.json') if r['candidate']==selected]
    values={}
    coverage=[]
    for i in range(3):
        split=read(run/('split.json' if i==0 else f'confirmation_split_{i}.json'))
        ids=[train_ids[k] for k in split['search_indices']]
        fitted=[train_ids[k] for k in split['train_indices']]
        require(not {groups[j] for j in ids}&{groups[j] for j in fitted},'A calibration group was used for fitting')
        trial=joblib.load(run/(f'trial_{number}.joblib' if not i else f'confirmation_{i}_{number}.joblib'))
        if 'search_scores' in trial:
            require(np.array_equal(trial['score_classes'],[0,1]),'Invalid stored probability domain')
            prob=trial['search_scores'][:,1]
        elif trial.get('model') is not None:
            prob=probabilities(data.kind,trial,take(data.X_train,ids),cache)
        else:
            coverage.append(dict(split=i,rows=len(ids),used=False,reason='hard predictions only'))
            continue
        coverage.append(dict(split=i,rows=len(ids),used=True))
        np.testing.assert_array_equal(prob>.5,trial['search_predictions'])
        require(fingerprint(data.y_train[ids])==trial['prediction_record']['label_sha256'],'Unexpected calibration labels')
        for idx,p in zip(ids,prob,strict=True):
            values.setdefault(idx,float(p))
    ids=sorted(values)
    require(bool(ids),'No genuine held-out probabilities')
    return ids,np.asarray([values[i] for i in ids]),coverage


def predict(args):
    receipts={}
    with threadpool_limits(limits=1):
        for case in CASES:
            data,groups,ref,prior,opened=source_data(args,case)
            records=[]
            for i,split in enumerate(prior['indices']):
                fold=ref/f'fold_{i}'
                run=fold/'auto'
                ic=CachedVectors(run) if data.kind=='pair_text' else None
                oc=CachedVectors(fold/'auto_prediction_features') if ic else None
                ids,p,coverage=inner_probabilities(data,groups,split['train'],run,ic)
                outer=split['outer']
                query=take(data.X_train,outer)
                base=probabilities(data.kind,joblib.load(run/'selected_model.joblib'),query,oc)
                past=read(fold/'outer_predictions.json')
                require(outer==past['rows'],'Wrong outer order')
                np.testing.assert_array_equal(base>.5,past['auto'])
                contexts,directions=memory_coordinates(data.kind,take(data.X_train,ids),query,ic,oc)
                index=np.arange(len(ids))
                newer=np.arange(len(ids),len(ids)+len(outer))
                truth=data.y_train[ids]
                residual=np.r_[truth-p,np.zeros(len(outer))]
                preds={'incumbent':(base>.5).astype(int).tolist()}
                decisions={}
                for name in ('real','sham'):
                    shuffled=name=='sham'
                    decision=fit_memory(contexts[index],directions[index] if directions is not None else None,
                                        p,truth,[groups[j] for j in ids],shuffled)
                    value=neighbors(contexts,directions,residual,index,newer,shuffled)
                    candidate=(base+decision['alpha']*value>.5).astype(int).tolist()
                    preds[name]=candidate if decision['accepted'] else preds['incumbent']
                    preds[name+'_without_check']=candidate
                    decisions[name]=decision
                out=args.out/case/f'fold_{i}'
                out.mkdir(parents=True,exist_ok=True)
                write(out/'predictions.json',dict(rows=outer,arms=preds))
                records.append(dict(decisions=decisions,rows=len(ids),inner_coverage=coverage,
                                prediction_sha256=digest(out/'predictions.json'),
                                cached_title_lookups=(ic.lookups+oc.lookups if ic else 0)))
                print(case,'sealed',i+1,flush=True)
            receipts[case]=dict(folds=records,training_members=opened)
    write(args.out/'sealed.json',dict(tasks=receipts,protocol_sha256=digest(args.out/'protocol.json')))


def score(args):
    sealed=read(args.out/'sealed.json')
    require(sealed['protocol_sha256']==digest(args.out/'protocol.json'),'Protocol changed')
    results={}
    for case in CASES:
        data,groups,ref,prior,_=source_data(args,case)
        folds=[]
        for i,rec in enumerate(sealed['tasks'][case]['folds']):
            dest=args.out/case/f'fold_{i}/predictions.json'
            require(rec['prediction_sha256']==digest(dest),'Prediction changed')
            b=read(dest)
            require(b['rows']==prior['indices'][i]['outer'],'Unexpected outer IDs')
            y=data.y_train[b['rows']]
            masks={a:np.asarray(pred)==y for a,pred in b['arms'].items()}
            folds.append(dict(rows=len(y),correct={a:int(m.sum()) for a,m in masks.items()},
                paired={a:dict(corrected=int((m&~masks['incumbent']).sum()),lost=int((~m&masks['incumbent']).sum()))
                        for a,m in masks.items() if a!='incumbent'},decisions=rec['decisions']))
        n=sum(f['rows'] for f in folds)
        correct={a:sum(f['correct'][a] for f in folds) for a in folds[0]['correct']}
        wins={a:sum(f['correct']['real']>f['correct'][a] for f in folds) for a in ('incumbent','sham')}
        results[case]=dict(rows=n,correct=correct,wins=wins,folds=folds,qualified=all(
                           correct['real']-correct[a]>=.002*n and wins[a]>=3 for a in wins))
        print(case,correct,wins)
    write(args.out/'results.json',dict(tasks=results,sealed_sha256=digest(args.out/'sealed.json'),
         usage=dict(new_base_fits=0,residual_strength_fits=20,new_encoder_forwards=0,new_llm_calls=0,incremental_rmb=0)))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase',choices=('freeze','predict','score'))
    for n in ('task1','task2','ref','out'):
        parser.add_argument('--'+n,type=Path,required=True)
    args=parser.parse_args()
    if args.phase=='freeze':
        args.out.mkdir(parents=True,exist_ok=False)
    else:
        require((args.out/'protocol.json').is_file(),'Freeze the study first')
    freeze_file(args.out/'protocol.json',frozen(args))
    if args.phase=='predict':
        require(not (args.out/'sealed.json').exists(),'Predictions have already been sealed')
        predict(args)
    elif args.phase=='score':
        score(args)
