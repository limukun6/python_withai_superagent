"""Use two previously sealed training-only benchmarks with the frozen open planner."""
import argparse
import csv
import json
from pathlib import Path
import shutil
from unittest.mock import patch

import numpy as np

from scripts import run_b_open_methods as study
from superagent.ab_run import sha,sources
from superagent.ab_scheduler import next_action
from superagent.ab_method_search import rank
from superagent.ab_run import freeze_partitions
from superagent.contracts import TaskSpec
from superagent.data import load_development_task
from superagent.splits import sample_groups
from tempfile import TemporaryDirectory


PLAN=study.ROOT/'docs/batches/B_open_released_transfer_20261124_zh.md'
SEED=51803


def previous_inputs(a,slot):
    if slot=='r1':
        arm=a.table/'path'
        old=study.read(a.table/'protocol.json')
        return a.table/'inputs/k3',arm,'standard',dict(train=old['train'],features=old['features'])
    arm=a.titles/'expanded'
    old=study.read(a.titles/'protocol.json')['inputs']
    return a.titles/'inputs/k1',arm,'varied',dict(train=old['k1/train.zip'],features=old['k1/features.zip'])


def replay_control(archive,arm):
    native=arm/'agent'
    state_actions=study.read(native/'actions.json')
    manifest=study.read(native/'run_manifest.json')
    caps=manifest['capabilities']
    task=load_development_task(archive)
    with TemporaryDirectory() as folder:
        trusted,_=freeze_partitions(task,Path(folder),SEED,TaskSpec.from_task(task).metric)
        for i,action in enumerate(state_actions,1):
            state=study.read(native/f'state_{i}.json')
            actual=next_action(state,capabilities=caps,trusted_partitions=trusted,on_local_method=lambda ids,rows:rank(state,caps,ids,rows))
            study.require(actual==action,'Existing control no longer replays')
    return len(state_actions),caps


def predictions(file):
    with file.open() as stream:
        rows=list(csv.DictReader(stream))
    study.require([r['row_id'] for r in rows]==list(map(str,range(len(rows)))),'Export order')
    return np.array([int(r['prediction']) for r in rows])


def run(a):
    out=a.out
    if not (out/'protocol.json').exists():
        out.mkdir(parents=True,exist_ok=False)
        items={}
        for slot in ('r1','r2'):
            src,arm,cat,pins=previous_inputs(a,slot)
            folder=out/'inputs'/slot
            folder.mkdir(parents=True)
            for key in ('train','features'):
                fname=key+'.zip'
                study.require(sha(src/fname)==pins[key],'Old training boundary changed')
                shutil.copyfile(src/fname,folder/fname)
            matched,caps=replay_control(folder/'train.zip',arm)
            items[slot]=dict(files={k:sha(folder/k) for k in ('train.zip','features.zip')},catalog=cat,
                             control=sha(arm/'frozen.json'),control_predictions=sha(arm/'export_0/rows.csv'),
                             control_actions_replayed=matched,shared_base_sha=study.fingerprint(caps))
        study.save(out/'protocol.json',dict(seed=SEED,plan=sha(PLAN),source=sources(),runner=sha(Path(__file__)),tasks=items,
                                          fit_limit=11,api_cap=0,outer_previously_used=True))
    p=study.read(out/'protocol.json')
    study.require(p['source']==sources() and p['plan']==sha(PLAN) and p['runner']==sha(Path(__file__)),'Frozen design changed')
    sealed={}
    for slot in ('r1','r2'):
        meta=p['tasks'][slot]
        folder=out/(slot+'_open')
        archive=out/'inputs'/slot/'train.zip'
        study.require(sha(archive)==meta['files']['train.zip'],'Training input drift')
        if not (folder/'agent/run_outcome.json').exists():
            folder.mkdir(exist_ok=False)
            study.cli(['run',archive,'--scheduler','ab-v1','--planner','local','--portfolio','ab-v1','--preference-catalog',meta['catalog'],
                       '--local-method-search','open','--task-profile','train','--fit-limit',11,'--seed',SEED,
                       '--time-limit',1200,'--trial-timeout',300,'--run-dir',folder/'agent'],folder/'physical.jsonl',folder/'train.log',1260)
        native_manifest=study.read(folder/'agent/run_manifest.json')
        study.require(native_manifest['seed']==SEED and study.fingerprint(native_manifest['capabilities'])==meta['shared_base_sha'],
                      'Control baseline or seed differs')
        # The shared replay helper uses the first study's seed by default. Only the independent auditor gets the prior seed.
        with patch.object(study,'SEED',SEED):
            result=study.audit(out,slot,'open',11)
        study.save(folder/'receipt.json',result)
        sealed[slot]=sha(folder/'receipt.json')
        print(slot,'sealed',result['winner'],result['actual_fits'],'fits',flush=True)
    study.save(out/'models_frozen.json',sealed)
    outputs={}
    for slot,n in (('r1',1269),('r2',746)):
        study.require(sha(out/(slot+'_open')/'receipt.json')==sealed[slot] and
                      sha(out/'inputs'/slot/'features.zip')==p['tasks'][slot]['files']['features.zip'],'Frozen export drift')
        outputs[slot]=[study.export(out,slot,'open',i,n) for i in (0,1)]
        study.require(outputs[slot][0]==outputs[slot][1],'Independent exports differ')
    study.save(out/'exports.json',outputs)
    table=study.read(a.table/'protocol.json')
    study.require(sha(a.parent)==table['input'],'Different original training-only table')
    raw=load_development_task(a.parent)
    g=sample_groups(raw)
    mask=[study.bin_id(key.encode(),'b-anonymous-table-varied-20261124/v1/',5)==0 for key in g]
    labels={'r1':raw.y_train[mask]}
    title_file=a.titles/'inputs/k1/score_only.npz'
    study.require(sha(title_file)==study.read(a.titles/'protocol.json')['inputs']['k1/score_only.npz'],'Changed title labels')
    with np.load(title_file,allow_pickle=False) as f:
        labels['r2']=f['labels']
    results={}
    for slot,y in labels.items():
        _,old,_,_=previous_inputs(a,slot)
        control_file=old/'export_0/rows.csv'
        study.require(sha(control_file)==p['tasks'][slot]['control_predictions'],'Control export drift')
        before=predictions(control_file)==y
        after=predictions(out/(slot+'_open')/'export_0/rows.csv')==y
        study.require(int(before.sum())==(936 if slot=='r1' else 541),'Mismatched old control score')
        results[slot]=dict(rows=len(y),old_correct=int(before.sum()),open_correct=int(after.sum()),
                           gained=int((after&~before).sum()),lost=int((before&~after).sum()))
    study.save(out/'results.json',results)
    study.save(out/'completion.json',{k:sha(out/(k+'.json')) for k in ('protocol','models_frozen','exports','results')})
    print(results,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('out','titles','table','parent'):
        parser.add_argument('--'+name,type=lambda v:Path(v).resolve(),required=True)
    run(parser.parse_args())
