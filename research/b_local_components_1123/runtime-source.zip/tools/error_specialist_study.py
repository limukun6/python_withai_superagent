"""Train-only, paired pilot of a data-induced local correction to archived default runs."""
import argparse
import os
from pathlib import Path

import joblib
import numpy as np

from superagent.data import TrainingTask, load_training_task
from superagent.error_specialist import ErrorSpecialist, SEED, paired_effect
from superagent.prediction_evidence import fingerprint
from superagent.pretrained_choice import digest
from superagent.splits import sample_groups, take
from tools.pretrained_study import read, train_only, write
from tools.soft_vote_diagnostic import freeze_file


ROOT = Path(__file__).resolve().parents[1]
CASES = ('task1', 'task2')
ARMS = ('incumbent', 'real_feedback', 'shuffled_feedback')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def snapshots(args):
    inputs = {}
    for case in CASES:
        ref = args.ref / ('release-auto-' + case)
        prior = read(ref / 'protocol.json')
        archive = getattr(args, case)
        require(digest(archive) == prior['archive_sha256'], 'Wrong original training package')
        require(prior['fold_numbers'] == list(range(1, 6)), 'Expected five complete reference folds')
        held = [i for split in prior['indices'] for i in split['outer']]
        require(len(held) == len(set(held)), 'Outer groups of rows overlap across folds')
        pool = set(held)
        for split in prior['indices']:
            train, outer = set(split['train']), set(split['outer'])
            require(not train & outer and train | outer == pool, 'Fold differs from the development pool')
        files = ['protocol.json']
        for i in range(5):
            prefix = f'fold_{i}/'
            folder = ref / prefix / 'auto'
            final = read(folder / 'final_selection.json')
            confirm = read(folder / 'confirmation.json')
            require(final['family'] == confirm['selected_candidate'] and confirm['valid_confirmation']
                    and confirm['primary_metric'] == 'accuracy', 'Require a confirmed accuracy incumbent')
            n, = [row['trial'] for row in read(folder / 'trials.json') if row['candidate'] == final['family']]
            files.append(prefix + 'outer_predictions.json')
            files += [prefix + 'auto/' + name for name in (
                'final_selection.json', 'task_spec.json', 'confirmation.json', 'trials.json', 'split.json', f'trial_{n}.joblib',
                'confirmation_split_1.json', 'confirmation_split_2.json',
                f'confirmation_1_{n}.joblib', f'confirmation_2_{n}.joblib')]
        inputs[case] = dict(seed=prior['seed'], rows=len(held), original_train_reserve=prior['reserved'],
                            archive_sha256=prior['archive_sha256'], files={f:digest(ref/f) for f in files})
    return dict(inputs=inputs, code={f:digest(ROOT/f) for f in
                    ('tools/error_specialist_study.py', 'superagent/error_specialist.py')},
                metric='accuracy', base_policy='auto', arms=list(ARMS), seed=SEED,
                plan='Keep one OOF prediction per row, taking its earliest stored inner split. '
                     'Separate groups 60/40 for discovery and confirmation. Learn one depth-at-most-three '
                     'tree leaf correction or abstain. Permute discovery actions within incumbent class for the placebo. '
                     'Both checks use real labels. Freeze every fold before exporting any outer predictions.',
                promotion='At least 0.2 percentage points and three strict fold wins versus both controls, per task. '
                          'Any qualifying result requires another grouped split before release.',
                accounting='Replay the original trained models’ held-out decisions. Count new specialist trees separately.')


def source_data(args, case):
    archive = getattr(args, case)
    opened = []
    with train_only(archive, opened):
        data = load_training_task(archive)
    ref = args.ref / ('release-auto-' + case)
    prior = read(ref / 'protocol.json')
    pool_ids = sorted(i for split in prior['indices'] for i in split['outer'])
    pool = TrainingTask(data.kind, take(data.X_train, pool_ids), np.empty(len(pool_ids)), data.spec)
    groups = dict(zip(pool_ids, sample_groups(pool, 'shared_text'), strict=True))
    for split in prior['indices']:
        require(not {groups[i] for i in split['train']} & {groups[i] for i in split['outer']},
                'Fold crosses feature-defined groups')
    return data, groups, ref, prior, opened


def inner_evidence(data, groups, train_ids, run):
    winner = read(run / 'confirmation.json')['selected_candidate']
    number, = [r['trial'] for r in read(run / 'trials.json') if r['candidate'] == winner]
    observed = {}
    for i in range(3):
        split = read(run / ('split.json' if not i else f'confirmation_split_{i}.json'))
        train = [train_ids[j] for j in split['train_indices']]
        held = [train_ids[j] for j in split['search_indices']]
        require(len(set(held)) == len(held) and not set(train) & set(held) and set(train) | set(held) == set(train_ids),
                'Invalid inner fit and evaluation partitions')
        require(not {groups[j] for j in train} & {groups[j] for j in held}, 'Inner group leakage')
        file = f'trial_{number}.joblib' if not i else f'confirmation_{i}_{number}.joblib'
        artifact = joblib.load(run / file)
        predictions, record = artifact['search_predictions'], artifact['prediction_record']
        require(fingerprint(data.y_train[held]) == record['label_sha256']
                and fingerprint(predictions) == record['prediction_sha256'], 'Wrong inner label or prediction order')
        for row, label in zip(held, predictions, strict=True):
            observed.setdefault(row, label)
    ids = sorted(observed)
    return ids, np.asarray([observed[i] for i in ids])


def learn(args):
    decisions = {}
    for case in CASES:
        data, groups, ref, prior, opened = source_data(args, case)
        records = []
        for i, split in enumerate(prior['indices']):
            folder = args.out / case / f'fold_{i}'
            folder.mkdir(parents=True, exist_ok=True)
            ids, anchor = inner_evidence(data, groups, split['train'], ref/f'fold_{i}/auto')
            spec = read(ref/f'fold_{i}/auto/task_spec.json')
            classes = spec['metric_spec']['labels']
            arms = {}
            for arm in ARMS[1:]:
                model = ErrorSpecialist(data.kind).fit(take(data.X_train, ids), anchor, data.y_train[ids],
                            [groups[j] for j in ids], classes, shuffle_feedback=(arm == 'shuffled_feedback'))
                dest = folder / (arm + '.joblib')
                joblib.dump(model, dest, compress=3)
                arms[arm] = dict(**model.report, model_sha256=digest(dest))
            records.append(dict(fold=i+1, unique_oof_rows=len(ids), inner_ids_sha256=fingerprint(ids), arms=arms))
        decisions[case] = dict(training_members=opened, folds=records)
    write(args.out/'decisions.json', decisions)


def predict(args):
    decisions = read(args.out/'decisions.json')
    seals = {}
    for case in CASES:
        data, _, ref, prior, _ = source_data(args, case)
        seals[case] = []
        for i, split in enumerate(prior['indices']):
            folder = args.out/case/f'fold_{i}'
            ids = split['outer']
            prior_export = read(ref/f'fold_{i}/outer_predictions.json')
            require(ids == prior_export['rows'], 'Outer row order changed')
            anchor = np.asarray(prior_export['auto'])
            features = take(data.X_train, ids)
            predictions = {'incumbent':anchor.tolist()}
            for arm in ARMS[1:]:
                path = folder/(arm+'.joblib')
                require(digest(path) == decisions[case]['folds'][i]['arms'][arm]['model_sha256'],
                        'Specialist changed after the grouped check')
                predictions[arm] = joblib.load(path).predict(features, anchor).tolist()
            write(folder/'predictions.json', dict(rows=ids, arms=predictions))
            seals[case].append(digest(folder/'predictions.json'))
    write(args.out/'prediction_seals.json', dict(decisions_sha256=digest(args.out/'decisions.json'), files=seals))


def score(args):
    seals = read(args.out/'prediction_seals.json')
    require(seals['decisions_sha256'] == digest(args.out/'decisions.json'), 'Frozen decisions changed')
    decisions = read(args.out/'decisions.json')
    totals = {}
    for case in CASES:
        data, groups, ref, prior, opened = source_data(args, case)
        folds = []
        for i, split in enumerate(prior['indices']):
            file = args.out/case/f'fold_{i}'/'predictions.json'
            require(digest(file) == seals['files'][case][i], 'Frozen outer predictions changed')
            batch = read(file)
            ids = split['outer']
            require(batch['rows'] == ids and all(len(v) == len(ids) for v in batch['arms'].values()), 'Missing rows')
            truth = data.y_train[ids]
            require(np.array_equal(truth, read(ref/f'fold_{i}/outer_predictions.json')['truth']), 'Wrong outer labels')
            preds = {arm:np.asarray(batch['arms'][arm]) for arm in ARMS}
            effects = {arm:paired_effect(truth, preds['incumbent'], preds[arm], [groups[j] for j in ids])
                       for arm in ARMS[1:]}
            folds.append(dict(rows=len(ids), correct={arm:int((p == truth).sum()) for arm,p in preds.items()},
                              effects=effects))
        n = sum(f['rows'] for f in folds)
        correct = {a:sum(f['correct'][a] for f in folds) for a in ARMS}
        wins = {a:sum(f['correct']['real_feedback'] > f['correct'][a] for f in folds)
                for a in ('incumbent','shuffled_feedback')}
        totals[case] = dict(rows=n, correct=correct, accuracy={a:v/n for a,v in correct.items()},
                            folds=folds, real_feedback_wins=wins,
                            trees_fitted={a:sum(f['arms'][a].get('tree_fitted',False) for f in decisions[case]['folds'])
                                          for a in ARMS[1:]},
                            accepted={a:sum(f['arms'][a]['accepted'] for f in decisions[case]['folds']) for a in ARMS[1:]},
                            qualified=all(correct['real_feedback']-correct[a] >= .002*n and wins[a]>=3 for a in wins),
                            training_members=opened)
    result = dict(tasks=totals, usage=dict(new_base_fits=0, new_encoder_forwards=0,
                  new_llm_requests=0, new_llm_input_tokens=0, new_llm_output_tokens=0, incremental_rmb=0),
                  protocol_sha256=digest(args.out/'protocol.json'), predictions_seal_sha256=digest(args.out/'prediction_seals.json'))
    write(args.out/'results.json', result)
    for case, values in totals.items():
        print(case, values['rows'], values['correct'], 'accepted', values['accepted'], 'qualified',values['qualified'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze','learn','predict','score'))
    for arg in ('task1','task2','ref','out'):
        parser.add_argument('--'+arg, type=Path, required=True)
    args = parser.parse_args()
    os.environ['SUPERAGENT_OFFLINE'] = '1'
    from tools.offline_guard import sitecustomize  # enable the repository's network and credential guard
    if args.phase == 'freeze':
        args.out.mkdir(parents=True, exist_ok=False)
    else:
        require((args.out/'protocol.json').is_file(), 'Freeze the pilot protocol before fitting or scoring')
    freeze_file(args.out/'protocol.json', snapshots(args))
    if args.phase == 'learn':
        require(not (args.out/'decisions.json').exists(), 'Use a new output directory to change fitted decisions')
        learn(args)
    elif args.phase == 'predict':
        require(not (args.out/'prediction_seals.json').exists(), 'Predictions have already been sealed')
        predict(args)
    elif args.phase == 'score':
        score(args)


if __name__ == '__main__':
    main()
