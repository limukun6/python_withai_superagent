"""A small supervised pooling head for frozen contextual token representations."""
import hashlib
import time

import numpy as np
import torch

from superagent.pair_attention import PairAttentionEncoder


WIDTH = 48
SEED = 72349
MODES = ('mean', 'permuted', 'learned')
EPOCHS = 10
BATCH = 192


def text_key(text):
    return hashlib.sha256(text.encode()).hexdigest()


def extract(texts, weights, destination):
    started = time.monotonic()
    encoder = PairAttentionEncoder(weights)
    tokens = [v.ids for v in encoder.tokenizer.encode_batch(texts)]
    lengths = np.asarray([len(seq) for seq in tokens])
    order = np.argsort(lengths, kind='stable')
    dim = encoder.model.config.hidden_size
    projection, _ = np.linalg.qr(np.random.default_rng(SEED).standard_normal((dim, WIDTH)))
    projection = torch.from_numpy(projection.astype('float32'))
    values = [None] * len(texts)
    padded_positions = 0
    with torch.inference_mode():
        for start in range(0, len(order), 64):
            ids = order[start:start + 64]
            width = int(max(lengths[ids]))
            matrix = torch.zeros((len(ids), width), dtype=torch.long)
            mask = torch.zeros_like(matrix)
            for k, idx in enumerate(ids):
                matrix[k, :lengths[idx]] = torch.tensor(tokens[idx])
                mask[k, :lengths[idx]] = 1
            hidden = encoder.model(input_ids=matrix, attention_mask=mask).last_hidden_state
            coordinates = (torch.nn.functional.normalize(hidden, dim=2) @ projection * np.sqrt(dim)).numpy()
            for k, idx in enumerate(ids):
                content = coordinates[k, 1:lengths[idx] - 1]
                values[idx] = (content if len(content) else coordinates[k, :1]).astype('float16')
            padded_positions += int(matrix.numel() - lengths[ids].sum())
    if not all(np.isfinite(v).all() for v in values):
        raise ValueError('Nonfinite frozen token representation')
    keys = [text_key(t) for t in texts]
    offsets = np.r_[0, np.cumsum([len(v) for v in values])]
    permutations = [np.random.default_rng(int(key[:16], 16) ^ SEED).permutation(len(value)).astype('int16')
                    for key, value in zip(keys, values, strict=True)]
    np.savez_compressed(destination, keys=keys, offsets=offsets, data=np.vstack(values), sham=np.concatenate(permutations))
    return dict(unique_items=len(texts), batches=(len(texts) + 63) // 64, input_tokens=int(lengths.sum()),
                padded_positions=padded_positions, seconds=time.monotonic()-started, device='cpu', incremental_rmb=0)


class Bank:
    def __init__(self, filename):
        with np.load(filename) as data:
            self.lookup = {s: i for i, s in enumerate(data['keys'])}
            self.offsets, self.values, self.sham = data['offsets'], data['data'], data['sham']
        if self.offsets[-1] != len(self.values) or len(self.sham) != len(self.values) or len(self.offsets) != len(self.lookup) + 1:
            raise ValueError('Incomplete token bank')

    def pairs(self, rows):
        return np.asarray([[self.lookup[text_key(t)] for t in pair] for pair in rows], dtype=int)

    def batch(self, items, permuted):
        starts = self.offsets[items]
        lengths = self.offsets[items + 1] - starts
        pos = np.arange(lengths.max())[None, :]
        mask = pos < lengths[:, None]
        indices = starts[:, None] + np.minimum(pos, lengths[:, None] - 1)
        values = torch.from_numpy(self.values[indices].astype('float32'))
        if permuted:
            key_indices = starts[:, None] + self.sham[indices]
            keys = torch.from_numpy(self.values[key_indices].astype('float32'))
        else:
            keys = values
        return values, keys, torch.from_numpy(mask)


def adjustment(bank, pairs, query, value, mode):
    values, keys, mask = bank.batch(pairs.ravel(), mode == 'permuted')
    scores = keys @ query if mode != 'mean' else torch.zeros_like(mask, dtype=torch.float32)
    weights = scores.masked_fill(~mask, -torch.inf).softmax(dim=1)
    weighted = ((values @ value) * weights).sum(dim=1).reshape(-1, 2)
    return weighted[:, 0] - weighted[:, 1]


def fit_head(bank, pairs, anchor_logits, y, mode):
    if mode not in MODES:
        raise ValueError('Unknown token pooling mode')
    query = torch.zeros(WIDTH, requires_grad=mode != 'mean')
    value = torch.zeros(WIDTH, requires_grad=True)
    parameters = [value] if mode == 'mean' else [value, query]
    optimizer = torch.optim.Adam(parameters, lr=.003)
    anchor = torch.from_numpy(np.asarray(anchor_logits, dtype='float32'))
    truth = torch.from_numpy(np.asarray(y, dtype='float32'))
    random = np.random.default_rng(SEED)
    for _ in range(EPOCHS):
        order = random.permutation(len(y))
        for start in range(0, len(y), BATCH):
            idx = order[start:start + BATCH]
            delta = adjustment(bank, pairs[idx], query, value, mode)
            loss = (torch.nn.functional.binary_cross_entropy_with_logits(anchor[idx] + delta, truth[idx]) +
                    .10 * delta.square().mean() + .01 * (query.square().sum() + value.square().sum()))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    return query.detach(), value.detach()


def predict_delta(bank, pairs, query, value, mode):
    with torch.inference_mode():
        return np.concatenate([adjustment(bank, pairs[i:i + BATCH], query, value, mode).numpy()
                               for i in range(0, len(pairs), BATCH)])
