"""Learn one input-dependent correction to a frozen classifier from held-out errors."""
import math
import re
from collections import Counter

import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import GroupShuffleSplit
from sklearn.tree import DecisionTreeClassifier


SEED = 113071


def row_features(kind, row):
    # The tree sees anonymous positions, observed values and words. No package or task ID is an input.
    if kind == 'pair_text':
        left, right = [set(re.findall(r'\w+', str(text).casefold())[:128]) for text in row]
        features = {f'either={word}': 1 for word in left | right}
        features.update({f'both={word}': 1 for word in left & right})
        features.update(shorter=min(len(left), len(right)), longer=max(len(left), len(right)),
                        shared=len(left & right))
        return features
    if kind == 'image':
        image = np.asarray(row, dtype=float)
        return {'mean': float(image.mean()), 'std': float(image.std()),
                'range': float(np.ptp(image))}
    cells = [row] if isinstance(row, str) else np.asarray(row, dtype=object).reshape(-1)
    features = {}
    for i, cell in enumerate(cells):
        key = f'field{i}'
        if isinstance(cell, (int, float, np.number)) and np.isfinite(float(cell)):
            features[key] = float(cell)
        else:
            words = re.findall(r'\w+', str(cell).casefold())[:128]
            features[f'{key}:length'] = len(words)
            if len(words) <= 4:
                features[f'{key}={str(cell).strip().casefold()}'] = 1
            for word in set(words):
                features[f'{key}:word={word}'] = 1
    return features


def paired_effect(truth, anchor, alternative, groups):
    before = anchor == truth
    after = alternative == truth
    differences = after.astype(int) - before.astype(int)
    _, inverse = np.unique(groups, return_inverse=True)
    clusters = np.bincount(inverse, weights=differences - differences.mean())
    count = len(clusters)
    se_total = math.sqrt(count / (count-1) * float(clusters @ clusters)) if count > 1 else None
    return dict(rows=len(truth), groups=count, changed=int(np.sum(anchor != alternative)),
                corrected=int(np.sum(after & ~before)), lost=int(np.sum(before & ~after)),
                net=int(differences.sum()), group_se_rows=se_total)


class ErrorSpecialist:
    """The base prediction is kept outside one proposed leaf, and everywhere if the check fails."""

    def __init__(self, kind):
        self.kind = kind
        self.accepted = False
        self.leaf = None
        self.action = None

    def replacements(self, anchor):
        if len(self.classes) == 2:
            return np.where(anchor == self.classes[0], self.classes[1], self.classes[0])
        return np.full(anchor.shape, self.classes[self.action - 1], dtype=self.classes.dtype)

    def matrix(self, rows):
        return self.vectorizer.transform(row_features(self.kind, row) for row in rows)

    def candidate_prediction(self, rows, anchor):
        proposal = np.asarray(anchor, dtype=self.classes.dtype).copy()
        if self.leaf is not None:
            mask = self.tree.apply(self.matrix(rows)) == self.leaf
            proposal[mask] = self.replacements(proposal[mask])
        return proposal

    def predict(self, rows, anchor):
        if len(rows) != len(anchor):
            raise ValueError('Input rows and baseline predictions differ in length')
        return self.candidate_prediction(rows, anchor) if self.accepted else np.asarray(anchor).copy()

    def fit(self, rows, anchor, truth, groups, classes, *, shuffle_feedback=False):
        self.accepted, self.leaf, self.action = False, None, None
        anchor, truth, groups = map(np.asarray, (anchor, truth, groups))
        self.classes = np.asarray(classes)
        if (anchor.shape != (len(rows),) or truth.shape != anchor.shape or groups.shape != anchor.shape
                or len(self.classes) < 2 or len(np.unique(self.classes)) != len(self.classes)
                or not np.isin(anchor, self.classes).all() or not np.isin(truth, self.classes).all()):
            raise ValueError('Inconsistent row, group or class domains')
        self.report = dict(accepted=False, reason='insufficient inner groups')
        if len(rows) < 60 or len(np.unique(groups)) < 16:
            return self
        split = GroupShuffleSplit(n_splits=1, test_size=.4, random_state=SEED)
        discovery, check = next(split.split(anchor, groups=groups))
        if set(groups[discovery]) & set(groups[check]):
            raise ValueError('The proposal and check share groups')
        self.report.update(discovery_rows=len(discovery), check_rows=len(check),
                           discovery_groups=len(np.unique(groups[discovery])),
                           check_groups=len(np.unique(groups[check])))
        lookup = {value: i + 1 for i, value in enumerate(self.classes)}
        labels = truth[discovery]
        actions = np.where(anchor[discovery] == labels, 0,
                           1 if len(self.classes) == 2 else [lookup[v] for v in labels])
        if shuffle_feedback:
            rng = np.random.default_rng(SEED)
            for value in self.classes:
                pos = np.flatnonzero(anchor[discovery] == value)
                actions[pos] = rng.permutation(actions[pos])
        self.vectorizer = DictVectorizer(dtype=np.float32)
        x = self.vectorizer.fit_transform(row_features(self.kind, rows[i]) for i in discovery)
        if x.shape[1] == 0:
            self.report['reason'] = 'no observable features'
            return self
        self.tree = DecisionTreeClassifier(max_depth=3, min_samples_leaf=max(20, math.ceil(.025 * len(actions))),
                                           random_state=SEED).fit(x, actions)
        leaves = self.tree.apply(x)
        best_gain = 0
        for leaf in np.unique(leaves):
            inside = leaves == leaf
            if len(np.unique(groups[discovery][inside])) < 8:
                continue
            counts = Counter(actions[inside])
            for candidate in sorted(set(counts) - {0}):
                # In multiclass, overriding a row already assigned this target cannot spoil it.
                was_right = actions[inside] == 0
                if len(self.classes) > 2:
                    was_right &= anchor[discovery][inside] != self.classes[candidate - 1]
                gain = counts[candidate] - int(was_right.sum())
                if gain > best_gain:
                    best_gain, self.leaf, self.action = gain, int(leaf), int(candidate)
        self.report['tree_fitted'] = True
        self.report['discovery_gain'] = int(best_gain)
        if self.leaf is None:
            self.report['reason'] = 'no profitable leaf in discovery'
            return self
        proposed = self.candidate_prediction([rows[i] for i in check], anchor[check])
        effect = paired_effect(truth[check], anchor[check], proposed, groups[check])
        se = effect['group_se_rows']
        self.accepted = bool(se is not None and effect['net'] >= max(.002*len(check), se))
        self.report.update(accepted=self.accepted, leaf=self.leaf, action=self.action,
                           reason='held-out group check passed' if self.accepted else 'held-out group check rejected',
                           confirmation=effect)
        return self
