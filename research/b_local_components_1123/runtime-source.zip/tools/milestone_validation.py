"""Seal every declared prediction before scoring the shared designated validation checkpoint."""
import argparse
import csv
import io
import tempfile
from pathlib import Path

import joblib
import numpy as np
import torch
from threadpoolctl import threadpool_limits

from superagent.data import load_prediction_features
from superagent.minilm_features import FILES
from superagent.pair_attention import PairAttentionEncoder
from superagent.predict import create_predictions
from superagent.pretrained_choice import digest
from tools.error_specialist_study import require
from tools.mainline_validation import (FEATURES, LABELS, PACKAGES, ROOT, now, prediction_path, read_member,
                                      read_predictions, stage_features, title_columns, verify_packages)
from tools.preference_adapter import HiddenBank, PreferenceAdapter, encode_items, predict as adapter_delta
from tools.pretrained_study import read, write
from tools.residual_memory_study import probabilities
from tools.soft_vote_diagnostic import freeze_file
from tools.token_pooling_study import logits
from tools.token_value_head import text_key


ARMS = {'table-structure':'task1', 'table-kernel':'task1', 'title-structure':'task2', 'title-adapter':'task2'}
PAST = ROOT/'validation/mainline-2026-11-20'


def protocol(args):
    sources = {}
    for name, case in ARMS.items():
        if name.endswith('structure'):
            folder = args.models/case
            model = folder/'portable'
            report = read(folder/'results.json')
            require(report['portable_model_sha256'] == digest(model/'selected_model.joblib'), 'Changed autonomous model')
            sources[name] = dict(selected=report['selected'], trials=report['trial_6_7'],
                                 hash=report['portable_model_sha256'], fit=digest(folder/'results.json'),
                                 selection=digest(model/'final_selection.json'), spec=digest(model/'task_spec.json'))
        else:
            folder = args.models/name
            report = read(folder/'fit.json')
            require(report['model_sha256']==digest(folder/report['file']) and report['fit_protocol_sha256']==digest(folder/'fit_protocol.json'),
                    'Changed experimental model')
            base = args.base/case/'run'
            base_hash = digest(base/'selected_model.joblib')
            require(base_hash == read(folder/'fit_protocol.json')['baseline'], 'Adjustment belongs to another base model')
            sources[name] = dict(fit=digest(folder/'fit.json'), hash=report['model_sha256'], base=base_hash,
                                 spec=digest(base/'task_spec.json'))
    return dict(arms=ARMS, sources=sources, course_role='development milestone on designated validation',
                registered_design=digest(ROOT/'research/next_mainline/milestone_design.md'), scorer=digest(Path(__file__)),
                previous_prediction_seals=digest(PAST/'predictions_frozen.json'), weights={k:v[1] for k,v in FILES.items()},
                packages={k:dict(sha256=v[1], features=FEATURES[k], labels=LABELS[k]) for k,v in PACKAGES.items()})


def baseline(case):
    return read_predictions(prediction_path(PAST,case), read(PAST/'predictions_frozen.json')['arms'][case])


class CachedSentenceBank:
    def __init__(self, bank):
        self.bank = bank

    def encode(self, items):
        return self.bank.full[[self.bank.keys[text_key(t)] for t in items]].numpy()


def predict_adjustment(args, name, staged, scratch):
    case = ARMS[name]
    source = args.base/case/'run'
    kind = 'pair_text' if case == 'task2' else 'categorical_tabular'
    rows = load_prediction_features(staged, kind, read(source/'task_spec.json'))
    base = joblib.load(source/'selected_model.joblib')
    meta = read(args.models/name/'fit.json')
    path = args.models/name/meta['file']
    if name == 'table-kernel':
        old = probabilities(kind, base, rows, None)
        np.testing.assert_array_equal(old>.5, baseline(case))
        strength = meta['decision']['alpha']
        kernel = joblib.load(path)
        values = old + strength*(kernel.probabilities(rows)-old)
        return (values>.5).astype(int), dict(coefficient=strength,language_model_calls=0,api_rmb=0)
    items = sorted({t for pair in rows for t in pair}, key=text_key)
    features = scratch/'milestone_title_features.npz'
    usage = encode_items(items,args.weights,features)
    bank = HiddenBank(features)
    original = base['model']
    original.encoder = CachedSentenceBank(bank)
    old = logits(original, rows)
    np.testing.assert_array_equal(old>0., baseline(case))
    pairs = bank.pairs(rows)
    layer = PairAttentionEncoder(args.weights).model.encoder.layer[-1]
    learner = PreferenceAdapter('inside').eval()
    learner.load_state_dict(torch.load(path,map_location='cpu',weights_only=True),strict=True)
    coeff = original.classifier.coef_[0,-384:]
    delta = adapter_delta(learner,bank,pairs,coeff,layer)
    require(np.isfinite(delta).all(), 'Non-finite adjusted decision')
    reverse = adapter_delta(learner,bank,pairs[:16,::-1],coeff,layer)
    np.testing.assert_allclose(reverse,-delta[:16],atol=1e-5)
    usage.update(adapted_item_visits=2*len(rows), reverse_check_item_visits=2*min(len(rows),16),
                 language_model_calls=0, api_rmb=0)
    return (old+delta>0.).astype(int), usage


def predict_all(args):
    require(not (args.out/'predictions_frozen.json').exists(),'Predictions are already sealed')
    hashes = {}
    with tempfile.TemporaryDirectory() as temporary:
        scratch = Path(temporary)
        for case in PACKAGES:
            stage_features(args.packages,case,scratch/(case+'.zip'))
        for name, case in ARMS.items():
            out = prediction_path(args.out,name)
            out.parent.mkdir(exist_ok=True)
            staged = scratch/(case+'.zip')
            if name.endswith('structure'):
                create_predictions(staged, args.models/case/'portable', out, minilm_weights=str(args.weights.resolve()))
                manifest = read(out.parent/'prediction_manifest.json')
                require(not manifest['test_labels_read'],'Unexpected labels in prediction')
                rows = manifest['prediction_count']
                usage = manifest.get('prediction_feature_usage',{'input_tokens':0,'api_rmb':0,'remote_calls':0})
            else:
                values, usage = predict_adjustment(args,name,staged,scratch)
                with out.open('w',newline='') as fd:
                    writer = csv.writer(fd)
                    writer.writerow(['row_id','prediction'])
                    writer.writerows(enumerate(values.tolist()))
                rows = len(values)
            hashes[name] = dict(rows=rows,prediction_sha256=digest(out),usage=usage)
            print(name, rows, 'sealed', flush=True)
    write(args.out/'predictions_frozen.json',dict(arms=hashes,protocol=digest(args.out/'protocol.json'),utc=now()))


def score(args):
    seal = read(args.out/'predictions_frozen.json')
    require(seal['protocol'] == digest(args.out/'protocol.json') and set(seal['arms']) == set(ARMS),'Changed validation seal')
    predictions = {k:read_predictions(prediction_path(args.out,k),seal['arms'][k]) for k in ARMS}
    tasks = {}
    for case, members in PACKAGES.items():
        content = read_member(args.packages,case,LABELS[case])
        y = (np.load(io.BytesIO(content),allow_pickle=False).reshape(-1) if case=='task1'
             else np.array([int(v[0]) for v in title_columns(content,['label_pairwise'])]))
        require(set(np.unique(y)) == {0,1},'Unrecognized validation labels')
        controls = {case:baseline(case)}
        if case=='task2':
            controls['task2-wide'] = baseline('task2-wide')
        local = {n:v for n,v in predictions.items() if ARMS[n]==case}
        all_preds = controls | local
        require(all(v.shape==y.shape for v in all_preds.values()),'Prediction length mismatch')
        hits = {k:v==y for k,v in all_preds.items()}
        tasks[case] = dict(rows=len(y),correct={k:int(v.sum()) for k,v in hits.items()},
            accuracy={k:float(v.mean()) for k,v in hits.items()},
            paired={n:{b:dict(corrected=int((hits[n]&~hits[b]).sum()),lost=int((~hits[n]&hits[b]).sum()))
                       for b in controls} for n in local})
    report = dict(tasks=tasks,metric='accuracy',split='designated course validation',
                  predictions=digest(args.out/'predictions_frozen.json'),official_test_members_opened=0)
    freeze_file(args.out/'scores.json',report)
    print({k:v['correct'] for k,v in tasks.items()})


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase',choices=('freeze','predict','score'))
    for item in ('packages','models','base','weights','out'):
        p.add_argument('--'+item,type=Path,required=True)
    args=p.parse_args()
    if args.phase=='freeze':
        args.out.mkdir(parents=True,exist_ok=False)
    else:
        require((args.out/'protocol.json').exists(),'Freeze all models first')
    verify_packages(args.packages)
    freeze_file(args.out/'protocol.json',protocol(args))
    with threadpool_limits(limits=2):
        if args.phase=='predict':
            predict_all(args)
        elif args.phase=='score':
            score(args)
